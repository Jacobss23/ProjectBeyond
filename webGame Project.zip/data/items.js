// === SEKCJA: PRZEDMIOTY ===
// size: [szerokość, wysokość] w polach siatki, stack: maks. ilość w jednym polu
const ITEMS = {
  // Podstawowe zaopatrzenie i medycyna
  ration: { name: "Racja żywnościowa", type: "consumable", size: [1, 1], value: 30, heal: 10 },
  cloth: { name: "Szmaty", type: "junk", size: [1, 1], stack: 5, value: 8 },
  bandage: { name: "Bandaż", type: "consumable", size: [1, 1], value: 45, heal: 20, cures: ["krwawienie"] },
  tourniquet: { name: "Bandaż uciskowy", type: "consumable", size: [1, 1], value: 65, heal: 10, cures: ["krwawienie", "mocne_krwawienie"] },
  hemostatic: { name: "Opatrunek hemostatyczny", type: "consumable", size: [1, 1], value: 50, heal: 25, cures: ["krwawienie", "mocne_krwawienie"] },
  ointment: { name: "Maść regeneracyjna", type: "consumable", size: [1, 1], value: 55, heal: 10, cures: ["siniak", "podraznienie"] },
  splint: { name: "Szyna usztywniająca", type: "consumable", size: [1, 2], value: 80, heal: 15, cures: ["zlamanie"] },
  medkit: { name: "Apteczka", type: "consumable", size: [2, 1], value: 120, heal: 45, cures: ["krwawienie", "zlamanie"] },
  morphine: { name: "Strzykawka morfiny", type: "consumable", size: [1, 1], value: 85, heal: 35, cures: ["strach"] },
  stim_adrenal: { name: "Stymulator bojowy Adrenal-X", type: "consumable", size: [1, 1], value: 160, heal: 55, cures: ["strach"], rarity: "rare" },
  stim_bleedstop: { name: "Stymulant BleedStop", type: "consumable", size: [1, 1], value: 140, heal: 25, buff: "bleedStop", buffDuration: 15, rarity: "rare" },
  saturn_cola: { name: "SaturnCola", type: "consumable", size: [1, 2], value: 110, heal: 20, buff: "saturnCola", buffDuration: 12 },
  decontam_kit: { name: "Pakiet dekontaminacyjny", type: "consumable", size: [1, 2], value: 130, heal: 40, cures: ["podraznienie"] },

  // Amunicja
  ammo9: { name: "Amunicja 9mm", type: "ammo", size: [1, 1], stack: 30, value: 6 },
  ammo12: { name: "Amunicja śrutowa 12G", type: "ammo", size: [1, 1], stack: 20, value: 10 },
  ammo556: { name: "Amunicja 5.56mm NATO", type: "ammo", size: [1, 1], stack: 30, value: 12 },
  ammo762: { name: "Amunicja 7.62mm Precyzyjna", type: "ammo", size: [1, 1], stack: 20, value: 18 },
  ammo_magnum: { name: "Amunicja .44 Magnum", type: "ammo", size: [1, 1], stack: 18, value: 15 },
  ammo_plasma: { name: "Ogniwa plazmowe", type: "ammo", size: [1, 1], stack: 15, value: 25, rarity: "rare" },

  // Broń biała
  wrench: { name: "Klucz hydrauliczny", type: "weapon", size: [1, 3], value: 40, dmg: [4, 8], acc: 0.9 },
  crowbar: { name: "Łom", type: "weapon", size: [1, 3], value: 70, dmg: [5, 10], acc: 0.85 },
  combat_knife: { name: "Nóż bojowy Tanto", type: "weapon", size: [1, 2], value: 90, dmg: [6, 12], acc: 0.92 },
  machete: { name: "Maczeta saperska", type: "weapon", size: [1, 3], value: 140, dmg: [8, 15], acc: 0.85 },
  axe_fire: { name: "Topór ratowniczy", type: "weapon", size: [2, 3], value: 210, dmg: [12, 20], acc: 0.8 },
  stun_baton: { name: "Pałka paraliżująca", type: "weapon", size: [1, 2], value: 180, dmg: [7, 14], acc: 0.88 },

  // Broń palna i zaawansowana
  pistol: { name: "Pistolet P-9", type: "weapon", size: [2, 1], value: 250, dmg: [8, 14], acc: 0.8, ammo: "ammo9" },
  revolver_magnum: { name: "Rewolwer Kolonialny .44", type: "weapon", size: [2, 1], value: 380, dmg: [16, 26], acc: 0.78, ammo: "ammo_magnum" },
  smg: { name: "Pistolet maszynowy Vex", type: "weapon", size: [3, 2], value: 600, dmg: [11, 17], acc: 0.72, ammo: "ammo9", rarity: "rare" },
  shotgun: { name: "Strzelba bojowa Striker", type: "weapon", size: [3, 1], value: 520, dmg: [18, 28], acc: 0.74, ammo: "ammo12" },
  rifle_assault: { name: "Karabin szturmowy ACR-K", type: "weapon", size: [3, 2], value: 780, dmg: [15, 23], acc: 0.82, ammo: "ammo556", rarity: "rare" },
  sniper_dragoon: { name: "Karabin snajperski Dragoon", type: "weapon", size: [4, 1], value: 980, dmg: [28, 45], acc: 0.92, ammo: "ammo762", rarity: "rare" },
  plasma_carbine: { name: "Karabinek plazmowy Nova-7", type: "weapon", size: [3, 2], value: 1250, dmg: [22, 34], acc: 0.86, ammo: "ammo_plasma", rarity: "rare" },

  // Pancerze i hełmy
  armor_damaged: { name: "Uszkodzony pancerz taktyczny", type: "armor", size: [3, 3], value: 150, def: 3 },
  armor_scout: { name: "Kombinezon zwiadowcy", type: "armor", size: [2, 3], value: 320, def: 4 },
  helmet_tactical: { name: "Hełm balistyczny", type: "armor", size: [2, 2], value: 240, def: 3 },
  armor_vest: { name: "Kamizelka kompozytowa", type: "armor", size: [3, 3], value: 450, def: 6, rarity: "rare" },
  vest_kevlar: { name: "Kamizelka kevlarowa S-2", type: "armor", size: [2, 3], value: 550, def: 7, rarity: "rare" },
  armor_exo: { name: "Pancerz szturmowy Exo-Titan", type: "armor", size: [3, 3], value: 920, def: 9, rarity: "rare" },

  // Przedmioty wydobywcze i narzędzia specjalne
  mining_glove: { name: "Głębinowy Chwytak Plazmowy", type: "tool", size: [2, 1], value: 650, uses: 5, rarity: "rare" },
  ore_titanium: { name: "Czysta Ruda Tytana", type: "junk", size: [1, 1], stack: 5, value: 280, rarity: "rare" },
  helium3: { name: "Izotop Hel-3 (Kriogeniczny)", type: "junk", size: [1, 1], stack: 3, value: 450, rarity: "rare" },
  xenonite_crystal: { name: "Kryształ Xenonitu", type: "junk", size: [1, 1], stack: 2, value: 850, rarity: "rare" },

  gas_mask: { name: "Maska filtrująca", type: "tool", size: [2, 1], value: 260, rarity: "rare" },

  // Ultra-rzadkie kosztowności (Valuable / Quests)
  relic_old_earth: { name: "Starożytny Relikt Ziemi", type: "valuable", size: [2, 1], value: 1800, rarity: "rare" },
  quantum_core: { name: "Kwantowy Rdzeń Szyfrujący", type: "valuable", size: [1, 2], value: 2200, rarity: "rare" },
  gold_ingot: { name: "Sztabka Złota Kolonialnego", type: "valuable", size: [1, 1], stack: 3, value: 1500, rarity: "rare" },
  titan_diamond: { name: "Diament Krystaliczny Tytana", type: "valuable", size: [1, 1], value: 3000, rarity: "rare" },
  sapphire_tesla: { name: "Szafir Tesli", type: "valuable", size: [1, 1], value: 1300, rarity: "rare" },
  lunar_pearl: { name: "Perła Księżycowa", type: "valuable", size: [1, 1], value: 1100, rarity: "rare" },
  golden_chalice: { name: "Złoty Kielich Kolonistów", type: "valuable", size: [2, 2], value: 1900, rarity: "rare" },
  platinum_wire: { name: "Platynowy drut mikroprocesorowy", type: "valuable", size: [1, 1], stack: 2, value: 1000, rarity: "rare" },
  ancient_tablet: { name: "Kamienna tablica Ziemi", type: "valuable", size: [2, 2], value: 2500, rarity: "rare" },
  artifact_orb: { name: "Kula Artefaktu Wega", type: "valuable", size: [1, 1], value: 1700, rarity: "rare" },
  holo_portrait: { name: "Hologram rodzinny z Ziemi", type: "valuable", size: [1, 2], value: 800, rarity: "rare" },
  emerald_xenon: { name: "Szmaragd Xenonowy", type: "valuable", size: [1, 1], value: 1400, rarity: "rare" },
  pocket_watch: { name: "Kieszonkowy zegarek z Ziemi", type: "valuable", size: [1, 1], value: 1200, rarity: "rare" },
  meteor_iron: { name: "Meteoryt żelazny", type: "valuable", size: [2, 1], stack: 2, value: 950, rarity: "rare" },

  // Surowce i złom
  scrap: { name: "Złom", type: "junk", size: [1, 1], stack: 5, value: 15 },
  wires: { name: "Przewody", type: "junk", size: [1, 1], stack: 5, value: 20 },
  circuit: { name: "Układ scalony", type: "junk", size: [1, 1], stack: 3, value: 60 },
  fuel_cell: { name: "Ogniwo paliwowe", type: "junk", size: [2, 2], value: 140 },
  data_chip: { name: "Chip danych", type: "junk", size: [1, 1], value: 220, rarity: "rare" },
  titan_filter: { name: "Filtr atmosferyczny kopuły", type: "junk", size: [1, 2], stack: 2, value: 180 },
  titan_fusion_core: { name: "Rdzeń fuzyjny Tytana", type: "junk", size: [2, 2], value: 350, rarity: "rare" },

  // Dropy biologiczne (Kopuła Tytana)
  infected_tissue: { name: "Tkanka mózgowa zarażonego", type: "junk", size: [1, 1], stack: 5, value: 75 },
  toxic_bile: { name: "Fiolka żrącej żółci", type: "junk", size: [1, 1], stack: 4, value: 95 },
  infected_tendon: { name: "Zmutowane ścięgno biegacza", type: "junk", size: [1, 1], stack: 6, value: 60 },
  pathogen_clot: { name: "Skrzep patogenu Tytana", type: "junk", size: [1, 1], stack: 3, value: 160, rarity: "rare" },

  // Przedmioty fabularne
  manual: { name: "Instrukcja serwisowa", type: "quest", quest: true, size: [1, 1], value: 0, read: "repair" },
  part_injector: { name: "Wtryskiwacz plazmowy", type: "quest", quest: true, size: [1, 2], value: 0 },
  part_coil: { name: "Cewka zapłonowa", type: "quest", quest: true, size: [2, 1], value: 0 },
  part_gasket: { name: "Uszczelka komory", type: "quest", quest: true, size: [2, 1], value: 0 },
  titan_med_key: { name: "Karta dostępu do szpitala", type: "quest", quest: true, size: [1, 1], value: 0 },
};

// === SEKCJA: ZESTAWY STARTOWE ===
const KITS = {
  "Lekki Frachtowiec": [
    ["wrench", 1],
    ["ration", 3],
    ["bandage", 2],
    ["ointment", 1],
    ["medkit", 1],
  ],
  "Myśliwiec Zwiadowczy": [
    ["pistol", 1],
    ["ammo9", 12],
    ["armor_damaged", 1],
    ["tourniquet", 1],
    ["saturn_cola", 1],
  ],
};

// === SEKCJA: RECEPTURY MODUŁÓW ===
const RECIPES = [
  { id: "r_glove", module: "Crafting", minLevel: 1, name: "Głębinowy Chwytak Plazmowy (Rękawica)", in: [["scrap", 3], ["wires", 2], ["fuel_cell", 1]], out: ["mining_glove", 1] },
  { id: "r_ammo", module: "Crafting", minLevel: 1, name: "Amunicja 9mm x8", in: [["scrap", 2], ["wires", 1]], out: ["ammo9", 8] },
  { id: "r_ammo12", module: "Crafting", minLevel: 1, name: "Amunicja śrutowa 12G x6", in: [["scrap", 2], ["wires", 1]], out: ["ammo12", 6] },
  { id: "r_ammo556", module: "Crafting", minLevel: 2, name: "Amunicja 5.56mm x10", in: [["scrap", 3], ["wires", 2], ["circuit", 1]], out: ["ammo556", 10] },
  { id: "r_knife", module: "Crafting", minLevel: 1, name: "Nóż bojowy Tanto", in: [["scrap", 3], ["cloth", 2]], out: ["combat_knife", 1] },
  { id: "r_shotgun", module: "Crafting", minLevel: 2, name: "Strzelba bojowa Striker", in: [["scrap", 8], ["wires", 3], ["circuit", 1]], out: ["shotgun", 1] },
  { id: "r_vest", module: "Crafting", minLevel: 2, name: "Kamizelka kompozytowa", in: [["armor_damaged", 1], ["scrap", 4], ["circuit", 1]], out: ["armor_vest", 1] },
  { id: "r_smg", module: "Crafting", minLevel: 3, name: "Pistolet maszynowy Vex", in: [["pistol", 1], ["scrap", 6], ["circuit", 2]], out: ["smg", 1] },
  { id: "r_bandage", module: "Medstation", minLevel: 1, name: "Bandaż", in: [["cloth", 2]], out: ["bandage", 1] },
  { id: "r_tourniquet", module: "Medstation", minLevel: 1, name: "Bandaż uciskowy", in: [["cloth", 3], ["wires", 1]], out: ["tourniquet", 1] },
  { id: "r_ointment", module: "Medstation", minLevel: 1, name: "Maść regeneracyjna", in: [["ration", 1], ["cloth", 1]], out: ["ointment", 1] },
  { id: "r_hemostatic", module: "Medstation", minLevel: 1, name: "Opatrunek hemostatyczny", in: [["cloth", 3], ["bandage", 1]], out: ["hemostatic", 1] },
  { id: "r_medkit", module: "Medstation", minLevel: 1, name: "Apteczka", in: [["bandage", 2], ["circuit", 1]], out: ["medkit", 1] },
  { id: "r_stim", module: "Medstation", minLevel: 2, name: "Stymulator bojowy Adrenal-X", in: [["morphine", 1], ["fuel_cell", 1], ["pathogen_clot", 1]], out: ["stim_adrenal", 1] },
  { id: "r_stim_bleedstop", module: "Medstation", minLevel: 2, name: "Stymulant BleedStop", in: [["hemostatic", 1], ["fuel_cell", 1]], out: ["stim_bleedstop", 1] },
];

if (typeof window !== "undefined") {
  window.ITEMS = ITEMS;
  window.KITS = KITS;
  window.RECIPES = RECIPES;
}
if (typeof globalThis !== "undefined") {
  globalThis.ITEMS = ITEMS;
  globalThis.KITS = KITS;
  globalThis.RECIPES = RECIPES;
}
