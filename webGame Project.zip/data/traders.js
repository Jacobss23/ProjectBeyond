// === SEKCJA: HANDLARZE I ZLECENIA ===
const TRADERS = [
  {
    id: "trader1",
    name: "Dr Jan Vane - Sanitariusz Polowy",
    desc: "Specjalista medycyny ratunkowej i epidemiolog. Skupuje próbki biologiczne i zaopatruje w leki.",
    buyMult: 1.4,
    sellMult: 1.0,
    color: "#10b981", // Emerald
    stock: {
      0: ["ration", "bandage", "hemostatic"],
      1: ["ointment", "splint", "saturn_cola"],
      2: ["medkit", "morphine", "decontam_kit", "stim_bleedstop"],
    },
  },
  {
    id: "trader2",
    name: "Sierżant Karras - Rusznikarz",
    desc: "Weteran wojen kolonialnych. Dostarcza broń, amunicję oraz modyfikacje taktyczne.",
    buyMult: 1.35,
    sellMult: 0.9,
    color: "#f59e0b", // Amber
    stock: {
      0: ["ammo9", "ammo12", "pistol", "shotgun", "combat_knife", "crowbar"],
      1: ["ammo556", "revolver_magnum", "smg", "rifle_assault"],
      2: ["ammo762", "ammo_magnum", "sniper_dragoon", "plasma_carbine"],
    },
  },
  {
    id: "trader3",
    name: "Inżynier Borys - Odzysk Komponentów",
    desc: "Zajmuje się demontażem technologii i rzadkimi podzespołami instalacji podtrzymywania życia.",
    buyMult: 1.5,
    sellMult: 1.15,
    color: "#06b6d4", // Cyan
    stock: {
      0: ["scrap", "wires", "wrench"],
      1: ["circuit", "fuel_cell"],
      2: ["titan_filter", "quantum_core"],
    },
  },
  {
    id: "trader4",
    name: "Kwatermistrz Nadia - Pancerze i Zaopatrzenie",
    desc: "Oficer zaopatrzeniowy wolnych kolonii. Handluje sprzętem ochronnym i kombinezonami.",
    buyMult: 1.45,
    sellMult: 1.0,
    color: "#6366f1", // Indigo
    stock: {
      0: ["armor_damaged", "helmet_tactical"],
      1: ["armor_scout", "vest_kevlar"],
      2: ["armor_vest", "armor_exo"],
    },
  },
  {
    id: "trader5",
    name: "Haker Val - Sieci i Wywiad",
    desc: "Kryptograf i analityk danych. Szuka czarnych skrzynek, chipów taktycznych i układów szyfrujących.",
    buyMult: 1.6,
    sellMult: 1.2,
    color: "#8b5cf6", // Violet
    stock: {
      0: ["data_chip"],
      1: ["circuit", "stim_adrenal"],
      2: ["fuel_cell", "quantum_core"],
    },
  },
  {
    id: "trader6",
    name: "Kapitan Sławiński - Dowódca Straży",
    desc: "Dowódca jednostki porządkowej. Zleca czyszczenie niebezpiecznych stref i polowanie na mutanty.",
    buyMult: 1.4,
    sellMult: 1.0,
    color: "#ef4444", // Crimson
    stock: {
      0: ["ammo9", "combat_knife"],
      1: ["ammo12", "vest_kevlar", "stim_bleedstop"],
      2: ["ammo556", "axe_fire", "rifle_assault"],
    },
  },
  {
    id: "trader7",
    name: "Profesor Thorne - Geolog Głębinowy",
    desc: "Badacz minerałów Tytana. Skupuje czystą rudę, xenonite i Hel-3. Sprzedaje Rękawicę Wydobywczą.",
    buyMult: 1.3,
    sellMult: 1.1,
    color: "#eab308", // Gold
    stock: {
      0: ["mining_glove"],
      1: ["ore_titanium", "helium3"],
      2: ["xenonite_crystal", "fuel_cell"],
    },
  },
  {
    id: "trader8",
    name: "Szturmowiec Jax - Szabrownik Sektora",
    desc: "Handlarz czarnorynkowy i kolekcjoner artefaktów. Odkupuje ultra-rzadkie kosztowności po najwyższych cenach.",
    buyMult: 1.7,
    sellMult: 1.3,
    color: "#ec4899", // Magenta
    stock: {
      0: ["data_chip", "crowbar"],
      1: ["quantum_core", "relic_old_earth"],
      2: ["gold_ingot", "titan_diamond", "armor_exo", "sniper_dragoon"],
    },
  },
];

// === SEKCJA: MISJE GŁÓWNE (MAIN QUESTS - BEZ TIERU) ===
const MAIN_QUESTS = [
  {
    id: "q0_supplies",
    traderId: "trader1",
    isMain: true,
    title: "Podstawowe Zaopatrzenie Medyczne",
    desc: "Dostarcz 2x Szmaty i 1x Złom na opatrunki i sterylizatory polowe.",
    req: [
      { id: "cloth", qty: 2 },
      { id: "scrap", qty: 1 },
    ],
    reward: { credits: 160, xp: 25, item: "bandage", itemQty: 2, rep: 20 },
  },
  {
    id: "q0_defense",
    traderId: "trader2",
    isMain: true,
    title: "Kalibracja Balistyczna",
    desc: "Przekaż 10x Amunicja 9mm oraz 1x Przewody do kalibracji magazynków.",
    req: [
      { id: "ammo9", qty: 10 },
      { id: "wires", qty: 1 },
    ],
    reward: { credits: 200, xp: 30, item: "combat_knife", itemQty: 1, rep: 20 },
  },
  {
    id: "q1_titan_tissue",
    traderId: "trader1",
    isMain: true,
    title: "Próbka Patogenu Tytana",
    desc: "Zlikwiduj zakażonych w Kopule Nowy Ereb na Tytanie i dostarcz 2x Tkanka mózgowa zarażonego.",
    req: [{ id: "infected_tissue", qty: 2 }],
    reward: { credits: 550, xp: 120, item: "stim_adrenal", itemQty: 1, rep: 30 },
  },
  {
    id: "q1_titan_firepower",
    traderId: "trader2",
    isMain: true,
    title: "Zabezpieczenie Amunicji Śrutowej",
    desc: "Przekaż 15x Amunicja śrutowa 12G na zbrojenie posterunku przeciwko biegaczom.",
    req: [{ id: "ammo12", qty: 15 }],
    reward: { credits: 500, xp: 110, item: "vest_kevlar", itemQty: 1, rep: 30 },
  },
  {
    id: "q1_titan_filter",
    traderId: "trader3",
    isMain: true,
    title: "Filtry Kopuły Tytana",
    desc: "Odzyskaj 1x Filtr atmosferyczny kopuły z systemu wentylacji Nowego Erebu.",
    req: [{ id: "titan_filter", qty: 1 }],
    reward: { credits: 650, xp: 130, item: "circuit", itemQty: 3, rep: 30 },
  },
  {
    id: "q1_titan_core",
    traderId: "trader4",
    isMain: true,
    title: "Rdzeń Fuzyjny Nowego Erebu",
    desc: "Zabezpiecz 1x Rdzeń fuzyjny Tytana z komory reaktora pod kopułą Tytana.",
    req: [{ id: "titan_fusion_core", qty: 1 }],
    reward: { credits: 900, xp: 200, item: "armor_exo", itemQty: 1, rep: 40 },
  },
  {
    id: "q1_val_quantum",
    traderId: "trader5",
    isMain: true,
    title: "Kwantowy Rdzeń Szyfrujący",
    desc: "Odzyskaj 1x Kwantowy Rdzeń Szyfrujący z najgłębszych sektorów Tytana.",
    req: [{ id: "quantum_core", qty: 1 }],
    reward: { credits: 1500, xp: 300, item: "stim_adrenal", itemQty: 2, rep: 50 },
  },
  {
    id: "q1_thorne_ore",
    traderId: "trader7",
    isMain: true,
    title: "Prospekcja Głębinowa Prometeusz",
    desc: "Użyj Głębinowego Chwytaka Plazmowego w Szybach Wydobywczych Prometeusz i dostarcz 2x Czysta Ruda Tytana oraz 1x Hel-3.",
    req: [
      { id: "ore_titanium", qty: 2 },
      { id: "helium3", qty: 1 },
    ],
    reward: { credits: 1100, xp: 220, item: "xenonite_crystal", itemQty: 1, rep: 40 },
  },
  {
    id: "q1_jax_relic",
    traderId: "trader8",
    isMain: true,
    title: "Artefakt Starej Ziemi",
    desc: "Odnajdź i przekaż 1x Starożytny Relikt Ziemi lub 1x Sztabka Złota Kolonialnego.",
    req: [{ id: "relic_old_earth", qty: 1 }],
    reward: { credits: 2400, xp: 400, item: "gold_ingot", itemQty: 1, rep: 50 },
  },

  // === SEKCJA: MISJE Z MINIGRĄ TERMINALA (jeden quest na handlarza) ===
  // terminal: { map, node, key, intel } – w rajdzie na podanej lokacji pojawia się
  // przycisk "Odczytaj terminal [T]". Trzeba znaleźć 3 wpisy zgodne z kluczem dostępu
  // wśród podobnych (różniących się 1 znakiem) i nie popełnić 3 błędów.
  // Po ewakuacji zaliczony terminal jest zapisany; oddanie przedmiotów u handlarza wymaga go.
  {
    id: "mt_trader1_terminal",
    traderId: "trader1",
    isMain: true,
    title: "Sekwencja ZETA-7",
    desc: "Odczytaj terminal w Laboratorium Izolacji (klucz dostępu w logu) i dostarcz 1x Tkanka mózgowa zarażonego.",
    req: [{ id: "infected_tissue", qty: 1 }],
        task: { type: "terminal", label: "Odczyt terminala", map: "titan_dome", node: "quarantine_lab", key: "K7Q2", intel: "ZETA-7: szczep odporny na standardowe antybiotyki. Próbka do sekwencjonowania." },
    reward: { credits: 400, xp: 90, item: "medkit", itemQty: 1, rep: 25 },
  },
  {
    id: "mt_trader2_terminal",
    traderId: "trader2",
    isMain: true,
    title: "Dziennik Magazynu Karrasa",
    desc: "Włam się do zamka skrytki na Alei Handlowej (zatrzymaj wskaźnik w zielonym polu) i dostarcz 10x Amunicja śrutowa 12G.",
    req: [{ id: "ammo12", qty: 10 }],
        task: { type: "hack", label: "Włamanie do zamka", map: "titan_dome", node: "concourse", intel: "Magazyn B: skrytka z bronią otwarta. Zapas strzelb w sektorze H." },
    reward: { credits: 350, xp: 80, item: "ammo9", itemQty: 20, rep: 25 },
  },
  {
    id: "mt_trader3_terminal",
    traderId: "trader3",
    isMain: true,
    title: "Diagnostyka Wentylacji",
    desc: "Podłącz przewody w Tunelu Wentylacyjnym do właściwych gniazd i dostarcz 1x Ogniwo paliwowe.",
    req: [{ id: "fuel_cell", qty: 1 }],
        task: { type: "wires", label: "Podłączenie przewodów", map: "titan_dome", node: "vent_tunnel", intel: "Wentylacja: filtr sektora C naprawiony po podłączeniu obwodu zasilania." },
    reward: { credits: 380, xp: 85, item: "wires", itemQty: 2, rep: 25 },
  },
  {
    id: "mt_trader4_terminal",
    traderId: "trader4",
    isMain: true,
    title: "Rejestr Mieszkalny Hab-4",
    desc: "Zapamiętaj i odtwórz sekwencję sygnałów w Sektorze Mieszkalnym Hab-4 i dostarcz 1x Kamizelka kevlarowa.",
    req: [{ id: "vest_kevlar", qty: 1 }],
        task: { type: "memory", label: "Sekwencja sygnałów", map: "titan_dome", node: "apartments", intel: "Hab-4: kod przydziału schronu to sekwencja z panelu – zapisana w pamięci strażnika." },
    reward: { credits: 420, xp: 95, item: "bandage", itemQty: 3, rep: 25 },
  },
  {
    id: "mt_trader5_terminal",
    traderId: "trader5",
    isMain: true,
    title: "Podsłuch Sieci Kolejowej",
    desc: "Odczytaj terminal na Stacji Kolejki Szynowej (klucz dostępu w logu) i dostarcz 2x Chip Danych.",
    req: [{ id: "data_chip", qty: 2 }],
        task: { type: "terminal", label: "Odczyt terminala", map: "titan_dome", node: "subway", key: "6HM1", intel: "Sieć szynowa: przełącznik zwrotnicy o kodzie 6HM1 zmieniono ręcznie. Ktoś tu był." },
    reward: { credits: 600, xp: 120, item: "circuit", itemQty: 2, rep: 30 },
  },
  {
    id: "mt_trader6_terminal",
    traderId: "trader6",
    isMain: true,
    title: "Raport Dowódcy Stacji",
    desc: "Włam się do zamka w laboratorium Wega-7 (zatrzymaj wskaźnik w zielonym polu) i dostarcz 2x Układ scalony.",
    req: [{ id: "circuit", qty: 2 }],
        task: { type: "hack", label: "Włamanie do zamka", map: "vega", node: "lab", intel: "Wega-7: dowództwo odblokowało sektor. Dane do ewakuacji dostępne." },
    reward: { credits: 550, xp: 110, item: "medkit", itemQty: 1, rep: 30 },
  },
  {
    id: "mt_trader7_terminal",
    traderId: "trader7",
    isMain: true,
    title: "Mapa Głębinowa Prometeusz",
    desc: "Podłącz przewody sondy przy Głębokim złożu Xenonitu i dostarcz 2x Ore Tytanu.",
    req: [{ id: "ore_titanium", qty: 2 }],
        task: { type: "wires", label: "Podłączenie przewodów", map: "titan_mines", node: "deep_xenonite", intel: "Złoże: sonda wskazuje żyłę xenonitu 40 m poniżej poziomu głównego." },
    reward: { credits: 700, xp: 140, item: "helium3", itemQty: 1, rep: 35 },
  },
  {
    id: "mt_trader8_terminal",
    traderId: "trader8",
    isMain: true,
    title: "Zapis Skarbca Starej Ziemi",
    desc: "Odtwórz sekwencję sygnałów skarbca w Kryptcie Prastarych Minerałów i dostarcz 1x Starożytny Relikt Ziemi.",
    req: [{ id: "relic_old_earth", qty: 1 }],
        task: { type: "memory", label: "Sekwencja sygnałów", map: "titan_mines", node: "relic_vault", intel: "Skarbiec: relikty przeniesiono do sektora ZIEMIA-1." },
    reward: { credits: 900, xp: 180, item: "gold_ingot", itemQty: 1, rep: 35 },
  },
];

// === SEKCJA: STRUKTURALNE MISJE TIEROWE (TIER 0, TIER 1, TIER 2) ===
// Każdy Tier zawiera: 2 startowe (phase: 1), kolejne 2 odblokowywane po zrobieniu 1 z nich (phase: 2) oraz 1 ostateczny quest (phase: "final").
const TIER_QUESTS = [
  // --- TRADER 1: Dr Jan Vane ---
  // Tier 0
  { id: "q0_t1_1", traderId: "trader1", tier: 0, phase: 1, title: "Opatrunki Polowe", desc: "Przekaż 2x Szmaty na bandaże uciskowe.", req: [{ id: "cloth", qty: 2 }], reward: { credits: 180, xp: 30, rep: 30, item: "hemostatic", itemQty: 1 } },
  { id: "q0_t1_2", traderId: "trader1", tier: 0, phase: 1, title: "Dezynfekcja Rur", desc: "Dostarcz 1x Złom i 1x Szmaty do produkcji sterylizatorów.", req: [{ id: "scrap", qty: 1 }, { id: "cloth", qty: 1 }], reward: { credits: 200, xp: 35, rep: 30, item: "ointment", itemQty: 1 } },
  { id: "q0_t1_3", traderId: "trader1", tier: 0, phase: 2, title: "Sterylne Naczynia", desc: "Przekaż 2x Przewody do podłączenia autoklawu.", req: [{ id: "wires", qty: 2 }], reward: { credits: 240, xp: 40, rep: 35, item: "bandage", itemQty: 2 } },
  { id: "q0_t1_4", traderId: "trader1", tier: 0, phase: 2, title: "Zapas Opatrunków Uciskowych", desc: "Zabezpiecz 2x Opatrunek uciskowy.", req: [{ id: "hemostatic", qty: 2 }], reward: { credits: 280, xp: 45, rep: 35, item: "saturn_cola", itemQty: 1 } },
  { id: "q0_t1_final", traderId: "trader1", tier: 0, phase: "final", title: "[FINAL TIER 0] Mobilny Punkt Sanitarny", desc: "Przekaż 2x Szyna i 2x Racja na utworzenie izby przyjęć.", req: [{ id: "splint", qty: 2 }, { id: "ration", qty: 2 }], reward: { credits: 800, xp: 120, rep: 80, item: "medkit", itemQty: 1 } },

  // Tier 1
  { id: "q2_t5_archive", traderId: "trader5", tier: 2, phase: 1, title: "Dane z Archiwum", desc: "Odtwórz sekwencję sygnałów w Regałach z Danymi (Archiwum) i dostarcz 2x Chip danych.", req: [{ id: "data_chip", qty: 2 }], task: { type: "memory", label: "Sekwencja sygnałów", map: "titan_archive", node: "stacks", intel: "Archiwum: plany Kolonii ukryte w sektorze Z-9." }, reward: { credits: 900, xp: 160, rep: 50, item: "titan_fusion_core", itemQty: 1 } },
  { id: "q2_t8_boss", traderId: "trader8", tier: 2, phase: "final", title: "Głowa Matki", desc: "Pokonaj Matkę Archiwum w Sali Matki i dostarcz 1x Kwantowy Rdzeń Szyfrujący.", req: [{ id: "quantum_core", qty: 1 }], kill: "archive_mother", reward: { credits: 1800, xp: 400, rep: 80, item: "gold_ingot", itemQty: 1 } },
  { id: "q1_t1_1", traderId: "trader1", tier: 1, phase: 1, title: "Synteza Antybiotyku", desc: "Dostarcz 1x Próbka zainfekowana do zbadania szczepu.", req: [{ id: "infected_tissue", qty: 1 }], reward: { credits: 450, xp: 90, rep: 40, item: "splint", itemQty: 2 } },
  { id: "q1_t1_2", traderId: "trader1", tier: 1, phase: 1, title: "Chłodzenie Szczepionek", desc: "Przekaż 1x Komórka paliwowa do zasilania chłodni leków.", req: [{ id: "fuel_cell", qty: 1 }], reward: { credits: 500, xp: 100, rep: 40, item: "medkit", itemQty: 1 } },
  { id: "q1_t1_3", traderId: "trader1", tier: 1, phase: 2, title: "Neutralizacja Toksyn", desc: "Dostarcz 1x Żółć toksyczna do produkcji odtrutek.", req: [{ id: "toxic_bile", qty: 1 }], reward: { credits: 550, xp: 110, rep: 45, item: "decontam_kit", itemQty: 1 } },
  { id: "q1_t1_4", traderId: "trader1", tier: 1, phase: 2, title: "Stymulanty Bojowe", desc: "Przekaż 2x SaturnCola na wzmocnienie krążenia pacjentów.", req: [{ id: "saturn_cola", qty: 2 }], reward: { credits: 600, xp: 120, rep: 45, item: "stim_bleedstop", itemQty: 1 } },
  { id: "q1_t1_final", traderId: "trader1", tier: 1, phase: "final", title: "[FINAL TIER 1] Klinika Epidemiologiczna Vane'a", desc: "Dostarcz 2x Zestaw dekontaminacyjny i 1x Skrzep patogenu.", req: [{ id: "decontam_kit", qty: 2 }, { id: "pathogen_clot", qty: 1 }], reward: { credits: 1800, xp: 280, rep: 120, item: "morphine", itemQty: 2 } },

  // Tier 2
  { id: "q2_t1_1", traderId: "trader1", tier: 2, phase: 1, title: "Serum Przeciwbólowe", desc: "Przekaż 2x Morfina dla stacji medycznej.", req: [{ id: "morphine", qty: 2 }], reward: { credits: 1000, xp: 200, rep: 50, item: "stim_adrenal", itemQty: 2 } },
  { id: "q2_t1_2", traderId: "trader1", tier: 2, phase: 1, title: "Dekontaminacja Sektora H", desc: "Dostarcz 2x Zestaw dekontaminacyjny.", req: [{ id: "decontam_kit", qty: 2 }], reward: { credits: 1100, xp: 220, rep: 50, item: "armor_exo", itemQty: 1 } },
  { id: "q2_t1_3", traderId: "trader1", tier: 2, phase: 2, title: "Biologiczny Przełom", desc: "Przekaż 2x Skrzep patogenu od mutanta.", req: [{ id: "pathogen_clot", qty: 2 }], reward: { credits: 1300, xp: 250, rep: 60, item: "stim_adrenal", itemQty: 2 } },
  { id: "q2_t1_4", traderId: "trader1", tier: 2, phase: 2, title: "Bariera Antywirusowa", desc: "Dostarcz 3x Próbka zainfekowana i 1x Kwantowy rdzeń.", req: [{ id: "infected_tissue", qty: 3 }, { id: "quantum_core", qty: 1 }], reward: { credits: 1600, xp: 300, rep: 60, item: "morphine", itemQty: 3 } },
  { id: "q2_t1_final", traderId: "trader1", tier: 2, phase: "final", title: "[FINAL TIER 2] Bioniczna Terapia Regeneracyjna", desc: "Przekaż 3x Morfina i 2x Stymulant adrenaliny.", req: [{ id: "morphine", qty: 3 }, { id: "stim_adrenal", qty: 2 }], reward: { credits: 4000, xp: 600, rep: 200, item: "gold_ingot", itemQty: 1 } },

  // --- TRADER 2: Sierżant Karras ---
  // Tier 0
  { id: "q0_t2_1", traderId: "trader2", tier: 0, phase: 1, title: "Zapas Pistoletowy", desc: "Przekaż 15x Amunicja 9mm do testów celności.", req: [{ id: "ammo9", qty: 15 }], reward: { credits: 200, xp: 35, rep: 30, item: "crowbar", itemQty: 1 } },
  { id: "q0_t2_2", traderId: "trader2", tier: 0, phase: 1, title: "Chłodzenie Lufy", desc: "Dostarcz 2x Złom na radiatory lufowe.", req: [{ id: "scrap", qty: 2 }], reward: { credits: 220, xp: 40, rep: 30, item: "ammo9", itemQty: 20 } },
  { id: "q0_t2_3", traderId: "trader2", tier: 0, phase: 2, title: "Ostrze Bojowe", desc: "Przekaż 1x Nóż Bojowy do wyważenia broni białej.", req: [{ id: "combat_knife", qty: 1 }], reward: { credits: 260, xp: 45, rep: 35, item: "ammo12", itemQty: 15 } },
  { id: "q0_t2_4", traderId: "trader2", tier: 0, phase: 2, title: "Obróbka Zamków", desc: "Dostarcz 2x Przewody do sprężyn automatycznych.", req: [{ id: "wires", qty: 2 }], reward: { credits: 300, xp: 50, rep: 35, item: "ammo9", itemQty: 25 } },
  { id: "q0_t2_final", traderId: "trader2", tier: 0, phase: "final", title: "[FINAL TIER 0] Zbrojownia Karrasa", desc: "Przekaż 1x Pistolet oraz 20x Amunicja 9mm.", req: [{ id: "pistol", qty: 1 }, { id: "ammo9", qty: 20 }], reward: { credits: 900, xp: 130, rep: 80, item: "shotgun", itemQty: 1 } },

  // Tier 1
  { id: "q1_t2_1", traderId: "trader2", tier: 1, phase: 1, title: "Kaliber 12G", desc: "Dostarcz 20x Amunicja śrutowa na zbrojenie.", req: [{ id: "ammo12", qty: 20 }], reward: { credits: 500, xp: 100, rep: 40, item: "vest_kevlar", itemQty: 1 } },
  { id: "q1_t2_2", traderId: "trader2", tier: 1, phase: 1, title: "Konserwacja Strzelb", desc: "Przekaż 1x Strzelba Taktyczna do przeglądu.", req: [{ id: "shotgun", qty: 1 }], reward: { credits: 650, xp: 130, rep: 40, item: "ammo556", itemQty: 30 } },
  { id: "q1_t2_3", traderId: "trader2", tier: 1, phase: 2, title: "Standard Karabinu", desc: "Dostarcz 25x Amunicja 5.56mm.", req: [{ id: "ammo556", qty: 25 }], reward: { credits: 700, xp: 140, rep: 45, item: "pistol", itemQty: 1 } },
  { id: "q1_t2_4", traderId: "trader2", tier: 1, phase: 2, title: "Zapasy Szturmowe", desc: "Przekaż 1x Układ scalony i 1x Złom na moduły celownicze.", req: [{ id: "circuit", qty: 1 }, { id: "scrap", qty: 1 }], reward: { credits: 750, xp: 150, rep: 45, item: "ammo556", itemQty: 30 } },
  { id: "q1_t2_final", traderId: "trader2", tier: 1, phase: "final", title: "[FINAL TIER 1] Baza Ogniowa Kolonii", desc: "Dostarcz 1x Karabin Szturmowy i 30x Amunicja 5.56mm.", req: [{ id: "rifle_assault", qty: 1 }, { id: "ammo556", qty: 30 }], reward: { credits: 2000, xp: 320, rep: 120, item: "axe_fire", itemQty: 1 } },

  // Tier 2
  { id: "q2_t2_1", traderId: "trader2", tier: 2, phase: 1, title: "Modyfikacja Snajperska", desc: "Przekaż 1x Karabin Szturmowy i 1x Układ scalony.", req: [{ id: "rifle_assault", qty: 1 }, { id: "circuit", qty: 1 }], reward: { credits: 1200, xp: 220, rep: 50, item: "ammo556", itemQty: 50 } },
  { id: "q2_t2_2", traderId: "trader2", tier: 2, phase: 1, title: "Ogień Ciężki", desc: "Dostarcz 50x Amunicja 5.56mm oraz 20x Amunicja 12G.", req: [{ id: "ammo556", qty: 50 }, { id: "ammo12", qty: 20 }], reward: { credits: 1500, xp: 280, rep: 60, item: "armor_exo", itemQty: 1 } },
  { id: "q2_t2_3", traderId: "trader2", tier: 2, phase: 2, title: "Rusznikarstwo Eksperymentalne", desc: "Dostarcz 2x Karabin Szturmowy do kalibracji podziałki.", req: [{ id: "rifle_assault", qty: 2 }], reward: { credits: 1800, xp: 320, rep: 60, item: "sniper_dragoon", itemQty: 1 } },
  { id: "q2_t2_4", traderId: "trader2", tier: 2, phase: 2, title: "Amunicja Przebijająca", desc: "Przekaż 1x Kwantowy rdzeń i 2x Układ scalony.", req: [{ id: "quantum_core", qty: 1 }, { id: "circuit", qty: 2 }], reward: { credits: 2100, xp: 360, rep: 60, item: "ammo556", itemQty: 100 } },
  { id: "q2_t2_final", traderId: "trader2", tier: 2, phase: "final", title: "[FINAL TIER 2] Działo Wyborowe Dragoon", desc: "Dostarcz 1x Karabin Wyborowy Dragoon i 50x Amunicja 5.56mm.", req: [{ id: "sniper_dragoon", qty: 1 }, { id: "ammo556", qty: 50 }], reward: { credits: 4500, xp: 650, rep: 200, item: "gold_ingot", itemQty: 1 } },

  // --- TRADER 3: Inżynier Borys ---
  // Tier 0
  { id: "q0_t3_1", traderId: "trader3", tier: 0, phase: 1, title: "Miedziane Przewody", desc: "Dostarcz 2x Przewody.", req: [{ id: "wires", qty: 2 }], reward: { credits: 200, xp: 35, rep: 30, item: "scrap", itemQty: 2 } },
  { id: "q0_t3_2", traderId: "trader3", tier: 0, phase: 1, title: "Złom na Przetop", desc: "Przekaż 3x Złom.", req: [{ id: "scrap", qty: 3 }], reward: { credits: 220, xp: 40, rep: 30, item: "wrench", itemQty: 1 } },
  { id: "q0_t3_3", traderId: "trader3", tier: 0, phase: 2, title: "Odzysk Płytki", desc: "Dostarcz 1x Układ scalony.", req: [{ id: "circuit", qty: 1 }], reward: { credits: 280, xp: 50, rep: 35, item: "wires", itemQty: 2 } },
  { id: "q0_t3_4", traderId: "trader3", tier: 0, phase: 2, title: "Ogniwo Maszynowni", desc: "Przekaż 1x Komórka paliwowa.", req: [{ id: "fuel_cell", qty: 1 }], reward: { credits: 320, xp: 55, rep: 35, item: "scrap", itemQty: 2 } },
  { id: "q0_t3_final", traderId: "trader3", tier: 0, phase: "final", title: "[FINAL TIER 0] Reaktor Borysa", desc: "Dostarcz 2x Układ scalony i 1x Komórka paliwowa.", req: [{ id: "circuit", qty: 2 }, { id: "fuel_cell", qty: 1 }], reward: { credits: 1000, xp: 150, rep: 80, item: "titan_filter", itemQty: 1 } },

  // Tier 1
  { id: "q1_t3_1", traderId: "trader3", tier: 1, phase: 1, title: "Wentylacja Sektora", desc: "Dostarcz 1x Filtr Tytan.", req: [{ id: "titan_filter", qty: 1 }], reward: { credits: 600, xp: 120, rep: 40, item: "fuel_cell", itemQty: 2 } },
  { id: "q1_t3_2", traderId: "trader3", tier: 1, phase: 1, title: "Chłodzenie Reaktora", desc: "Przekaż 2x Komórka paliwowa.", req: [{ id: "fuel_cell", qty: 2 }], reward: { credits: 700, xp: 140, rep: 40, item: "circuit", itemQty: 2 } },
  { id: "q1_t3_3", traderId: "trader3", tier: 1, phase: 2, title: "Mikroprocesory Szyfrujące", desc: "Dostarcz 2x Chip Danych.", req: [{ id: "data_chip", qty: 2 }], reward: { credits: 800, xp: 160, rep: 45, item: "quantum_core", itemQty: 1 } },
  { id: "q1_t3_4", traderId: "trader3", tier: 1, phase: 2, title: "Magazyn Narzędzi", desc: "Przekaż 1x Klucz Francuski i 3x Złom.", req: [{ id: "wrench", qty: 1 }, { id: "scrap", qty: 3 }], reward: { credits: 850, xp: 170, rep: 45, item: "circuit", itemQty: 3 } },
  { id: "q1_t3_final", traderId: "trader3", tier: 1, phase: "final", title: "[FINAL TIER 1] Zintegrowana Sieć Borysa", desc: "Dostarcz 2x Układ scalony, 2x Komórka paliwowa i 1x Filtr Tytan.", req: [{ id: "circuit", qty: 2 }, { id: "fuel_cell", qty: 2 }, { id: "titan_filter", qty: 1 }], reward: { credits: 2200, xp: 350, rep: 120, item: "quantum_core", itemQty: 1 } },

  // Tier 2
  { id: "q2_t3_1", traderId: "trader3", tier: 2, phase: 1, title: "Rdzeń Syntezy", desc: "Dostarcz 1x Kwantowy Rdzeń.", req: [{ id: "quantum_core", qty: 1 }], reward: { credits: 1400, xp: 250, rep: 50, item: "titan_filter", itemQty: 2 } },
  { id: "q2_t3_2", traderId: "trader3", tier: 2, phase: 1, title: "Sieć Maszynowa", desc: "Przekaż 3x Układ scalony i 2x Komórka paliwowa.", req: [{ id: "circuit", qty: 3 }, { id: "fuel_cell", qty: 2 }], reward: { credits: 1600, xp: 290, rep: 60, item: "armor_exo", itemQty: 1 } },
  { id: "q2_t3_3", traderId: "trader3", tier: 2, phase: 2, title: "Filtry Hybrydowe", desc: "Dostarcz 2x Filtr Tytan.", req: [{ id: "titan_filter", qty: 2 }], reward: { credits: 1800, xp: 320, rep: 60, item: "quantum_core", itemQty: 1 } },
  { id: "q2_t3_4", traderId: "trader3", tier: 2, phase: 2, title: "Komponenty Antymaterii", desc: "Przekaż 2x Kwantowy Rdzeń.", req: [{ id: "quantum_core", qty: 2 }], reward: { credits: 2200, xp: 380, rep: 60, item: "gold_ingot", itemQty: 1 } },
  { id: "q2_t3_final", traderId: "trader3", tier: 2, phase: "final", title: "[FINAL TIER 2] Generator Pola Antymaterii", desc: "Dostarcz 2x Kwantowy Rdzeń i 2x Filtr Tytan.", req: [{ id: "quantum_core", qty: 2 }, { id: "titan_filter", qty: 2 }], reward: { credits: 5000, xp: 700, rep: 200, item: "gold_ingot", itemQty: 1 } },

  // --- TRADER 4: Kwatermistrz Nadia ---
  // Tier 0
  { id: "q0_t4_1", traderId: "trader4", tier: 0, phase: 1, title: "Łaty na Pancerz", desc: "Dostarcz 2x Szmaty i 1x Złom.", req: [{ id: "cloth", qty: 2 }, { id: "scrap", qty: 1 }], reward: { credits: 210, xp: 35, rep: 30, item: "armor_damaged", itemQty: 1 } },
  { id: "q0_t4_2", traderId: "trader4", tier: 0, phase: 1, title: "Wzmocnienie Płyt", desc: "Przekaż 2x Złom.", req: [{ id: "scrap", qty: 2 }], reward: { credits: 230, xp: 40, rep: 30, item: "helmet_tactical", itemQty: 1 } },
  { id: "q0_t4_3", traderId: "trader4", tier: 0, phase: 2, title: "Sprawdzenie Hełmu", desc: "Dostarcz 1x Hełm Taktyczny.", req: [{ id: "helmet_tactical", qty: 1 }], reward: { credits: 280, xp: 45, rep: 35, item: "armor_damaged", itemQty: 1 } },
  { id: "q0_t4_4", traderId: "trader4", tier: 0, phase: 2, title: "Pancerz Lekki", desc: "Przekaż 1x Uszkodzony pancerz.", req: [{ id: "armor_damaged", qty: 1 }], reward: { credits: 320, xp: 50, rep: 35, item: "vest_kevlar", itemQty: 1 } },
  { id: "q0_t4_final", traderId: "trader4", tier: 0, phase: "final", title: "[FINAL TIER 0] Zbrojownia Nadii", desc: "Dostarcz 1x Uszkodzony pancerz i 1x Hełm Taktyczny.", req: [{ id: "armor_damaged", qty: 1 }, { id: "helmet_tactical", qty: 1 }], reward: { credits: 950, xp: 140, rep: 80, item: "armor_scout", itemQty: 1 } },

  // Tier 1
  { id: "q1_t4_1", traderId: "trader4", tier: 1, phase: 1, title: "Pancerz Zwiadu", desc: "Dostarcz 1x Pancerz Zwiadowcy.", req: [{ id: "armor_scout", qty: 1 }], reward: { credits: 650, xp: 130, rep: 40, item: "vest_kevlar", itemQty: 1 } },
  { id: "q1_t4_2", traderId: "trader4", tier: 1, phase: 1, title: "Kevlar dla Straży", desc: "Przekaż 1x Kamizelka Kevlar.", req: [{ id: "vest_kevlar", qty: 1 }], reward: { credits: 700, xp: 140, rep: 40, item: "armor_vest", itemQty: 1 } },
  { id: "q1_t4_3", traderId: "trader4", tier: 1, phase: 2, title: "Płyty Balistyczne", desc: "Dostarcz 3x Złom i 1x Przewody.", req: [{ id: "scrap", qty: 3 }, { id: "wires", qty: 1 }], reward: { credits: 750, xp: 150, rep: 45, item: "helmet_tactical", itemQty: 1 } },
  { id: "q1_t4_4", traderId: "trader4", tier: 1, phase: 2, title: "Zbroja Bojowa", desc: "Przekaż 1x Uszczelniona Kamizelka.", req: [{ id: "armor_vest", qty: 1 }], reward: { credits: 900, xp: 180, rep: 45, item: "armor_exo", itemQty: 1 } },
  { id: "q1_t4_final", traderId: "trader4", tier: 1, phase: "final", title: "[FINAL TIER 1] Przednia Linia Nadii", desc: "Dostarcz 1x Uszczelniona Kamizelka i 1x Kamizelka Kevlar.", req: [{ id: "armor_vest", qty: 1 }, { id: "vest_kevlar", qty: 1 }], reward: { credits: 2300, xp: 360, rep: 120, item: "armor_exo", itemQty: 1 } },

  // Tier 2
  { id: "q2_t4_1", traderId: "trader4", tier: 2, phase: 1, title: "Tarcza Egzoszkieletu", desc: "Przekaż 1x Pancerz Egzoszkielet.", req: [{ id: "armor_exo", qty: 1 }], reward: { credits: 1500, xp: 260, rep: 50, item: "fuel_cell", itemQty: 2 } },
  { id: "q2_t4_2", traderId: "trader4", tier: 2, phase: 1, title: "Pancerz Tytanowy", desc: "Dostarcz 2x Ruda Tytana i 2x Złom.", req: [{ id: "ore_titanium", qty: 2 }, { id: "scrap", qty: 2 }], reward: { credits: 1800, xp: 300, rep: 60, item: "quantum_core", itemQty: 1 } },
  { id: "q2_t4_3", traderId: "trader4", tier: 2, phase: 2, title: "Kombinezon Ciężki", desc: "Dostarcz 1x Pancerz Egzoszkielet i 1x Uszczelniona Kamizelka.", req: [{ id: "armor_exo", qty: 1 }, { id: "armor_vest", qty: 1 }], reward: { credits: 2200, xp: 380, rep: 60, item: "gold_ingot", itemQty: 1 } },
  { id: "q2_t4_4", traderId: "trader4", tier: 2, phase: 2, title: "Osłona Reaktorowa", desc: "Przekaż 2x Filtr Tytan i 2x Komórka paliwowa.", req: [{ id: "titan_filter", qty: 2 }, { id: "fuel_cell", qty: 2 }], reward: { credits: 2500, xp: 420, rep: 60, item: "quantum_core", itemQty: 1 } },
  { id: "q2_t4_final", traderId: "trader4", tier: 2, phase: "final", title: "[FINAL TIER 2] Forteca Kolonialna", desc: "Dostarcz 1x Pancerz Egzoszkielet i 1x Hel-3.", req: [{ id: "armor_exo", qty: 1 }, { id: "helium3", qty: 1 }], reward: { credits: 4800, xp: 680, rep: 200, item: "gold_ingot", itemQty: 1 } },

  // --- TRADER 5: Haker Val ---
  // Tier 0
  { id: "q0_t5_1", traderId: "trader5", tier: 0, phase: 1, title: "Logi Terminalu", desc: "Dostarcz 1x Chip Danych.", req: [{ id: "data_chip", qty: 1 }], reward: { credits: 250, xp: 40, rep: 30, item: "circuit", itemQty: 1 } },
  { id: "q0_t5_2", traderId: "trader5", tier: 0, phase: 1, title: "Kable Danych", desc: "Przekaż 2x Przewody.", req: [{ id: "wires", qty: 2 }], reward: { credits: 230, xp: 35, rep: 30, item: "data_chip", itemQty: 1 } },
  { id: "q0_t5_3", traderId: "trader5", tier: 0, phase: 2, title: "Płytka Łącza", desc: "Dostarcz 1x Układ scalony.", req: [{ id: "circuit", qty: 1 }], reward: { credits: 300, xp: 50, rep: 35, item: "data_chip", itemQty: 1 } },
  { id: "q0_t5_4", traderId: "trader5", tier: 0, phase: 2, title: "Czarne Skrzynki", desc: "Przekaż 2x Chip Danych.", req: [{ id: "data_chip", qty: 2 }], reward: { credits: 350, xp: 60, rep: 35, item: "fuel_cell", itemQty: 1 } },
  { id: "q0_t5_final", traderId: "trader5", tier: 0, phase: "final", title: "[FINAL TIER 0] Serwerownia Val", desc: "Dostarcz 2x Chip Danych i 1x Układ scalony.", req: [{ id: "data_chip", qty: 2 }, { id: "circuit", qty: 1 }], reward: { credits: 1100, xp: 160, rep: 80, item: "quantum_core", itemQty: 1 } },

  // Tier 1
  { id: "q1_t5_1", traderId: "trader5", tier: 1, phase: 1, title: "Szyfr Kwantowy", desc: "Dostarcz 1x Kwantowy rdzeń.", req: [{ id: "quantum_core", qty: 1 }], reward: { credits: 800, xp: 160, rep: 40, item: "data_chip", itemQty: 2 } },
  { id: "q1_t5_2", traderId: "trader5", tier: 1, phase: 1, title: "Dekodowanie Relektro", desc: "Przekaż 2x Chip Danych.", req: [{ id: "data_chip", qty: 2 }], reward: { credits: 750, xp: 150, rep: 40, item: "stim_adrenal", itemQty: 1 } },
  { id: "q1_t5_3", traderId: "trader5", tier: 1, phase: 2, title: "Zasilanie Węzła", desc: "Dostarcz 2x Komórka paliwowa.", req: [{ id: "fuel_cell", qty: 2 }], reward: { credits: 850, xp: 170, rep: 45, item: "quantum_core", itemQty: 1 } },
  { id: "q1_t5_4", traderId: "trader5", tier: 1, phase: 2, title: "Przechwycony Sygnał", desc: "Przekaż 2x Układ scalony i 1x Przewody.", req: [{ id: "circuit", qty: 2 }, { id: "wires", qty: 1 }], reward: { credits: 900, xp: 180, rep: 45, item: "stim_bleedstop", itemQty: 2 } },
  { id: "q1_t5_final", traderId: "trader5", tier: 1, phase: "final", title: "[FINAL TIER 1] Czarne Łącze Val", desc: "Dostarcz 1x Kwantowy rdzeń i 2x Układ scalony.", req: [{ id: "quantum_core", qty: 1 }, { id: "circuit", qty: 2 }], reward: { credits: 2500, xp: 380, rep: 120, item: "relic_old_earth", itemQty: 1 } },

  // Tier 2
  { id: "q2_t5_1", traderId: "trader5", tier: 2, phase: 1, title: "Krypto-Rdzenie", desc: "Przekaż 2x Kwantowy rdzeń.", req: [{ id: "quantum_core", qty: 2 }], reward: { credits: 1600, xp: 280, rep: 50, item: "fuel_cell", itemQty: 2 } },
  { id: "q2_t5_2", traderId: "trader5", tier: 2, phase: 1, title: "Infiltracja Danych", desc: "Dostarcz 3x Chip Danych i 2x Komórka paliwowa.", req: [{ id: "data_chip", qty: 3 }, { id: "fuel_cell", qty: 2 }], reward: { credits: 1900, xp: 320, rep: 60, item: "gold_ingot", itemQty: 1 } },
  { id: "q2_t5_3", traderId: "trader5", tier: 2, phase: 2, title: "Krypto-Skanery", desc: "Dostarcz 3x Układ scalony i 2x Chip Danych.", req: [{ id: "circuit", qty: 3 }, { id: "data_chip", qty: 2 }], reward: { credits: 2200, xp: 380, rep: 60, item: "quantum_core", itemQty: 1 } },
  { id: "q2_t5_4", traderId: "trader5", tier: 2, phase: 2, title: "Czarna Skrzynka Relektro", desc: "Przekaż 2x Kwantowy rdzeń.", req: [{ id: "quantum_core", qty: 2 }], reward: { credits: 2600, xp: 440, rep: 60, item: "titan_diamond", itemQty: 1 } },
  { id: "q2_t5_final", traderId: "trader5", tier: 2, phase: "final", title: "[FINAL TIER 2] Głęboki Wywiad Sektora", desc: "Dostarcz 2x Kwantowy rdzeń i 1x Starożytny Relikt.", req: [{ id: "quantum_core", qty: 2 }, { id: "relic_old_earth", qty: 1 }], reward: { credits: 5000, xp: 700, rep: 200, item: "xenonite_crystal", itemQty: 1 } },

  // --- TRADER 6: Kapitan Sławiński ---
  // Tier 0
  { id: "q0_t6_1", traderId: "trader6", tier: 0, phase: 1, title: "Patrol Marsa", desc: "Dostarcz 2x Szmaty i 10x Amunicja 9mm.", req: [{ id: "cloth", qty: 2 }, { id: "ammo9", qty: 10 }], reward: { credits: 220, xp: 40, rep: 30, item: "ammo9", itemQty: 15 } },
  { id: "q0_t6_2", traderId: "trader6", tier: 0, phase: 1, title: "Pacyfikacja Sektora", desc: "Przekaż 1x Nóż Bojowy z pobojowiska.", req: [{ id: "combat_knife", qty: 1 }], reward: { credits: 250, xp: 45, rep: 30, item: "armor_damaged", itemQty: 1 } },
  { id: "q0_t6_3", traderId: "trader6", tier: 0, phase: 2, title: "Ostrzał Obronny", desc: "Dostarcz 15x Amunicja Śrutowa.", req: [{ id: "ammo12", qty: 15 }], reward: { credits: 300, xp: 50, rep: 35, item: "vest_kevlar", itemQty: 1 } },
  { id: "q0_t6_4", traderId: "trader6", tier: 0, phase: 2, title: "Zabezpieczenie Trasy", desc: "Przekaż 2x Złom.", req: [{ id: "scrap", qty: 2 }], reward: { credits: 280, xp: 45, rep: 35, item: "ammo9", itemQty: 20 } },
  { id: "q0_t6_final", traderId: "trader6", tier: 0, phase: "final", title: "[FINAL TIER 0] Posterunek Straży", desc: "Dostarcz 1x Nóż Bojowy i 20x Amunicja 9mm.", req: [{ id: "combat_knife", qty: 1 }, { id: "ammo9", qty: 20 }], reward: { credits: 1000, xp: 150, rep: 80, item: "axe_fire", itemQty: 1 } },

  // Tier 1
  { id: "q1_t6_1", traderId: "trader6", tier: 1, phase: 1, title: "Polowanie na Mutanta", desc: "Przekaż 1x Skrzep patogenu od pokonanego potwora.", req: [{ id: "pathogen_clot", qty: 1 }], reward: { credits: 750, xp: 150, rep: 40, item: "axe_fire", itemQty: 1 } },
  { id: "q1_t6_2", traderId: "trader6", tier: 1, phase: 1, title: "Zapasy Szturmowe Straży", desc: "Dostarcz 25x Amunicja 5.56mm.", req: [{ id: "ammo556", qty: 25 }], reward: { credits: 800, xp: 160, rep: 40, item: "vest_kevlar", itemQty: 1 } },
  { id: "q1_t6_3", traderId: "trader6", tier: 1, phase: 2, title: "Broń Ciężka Straży", desc: "Przekaż 1x Karabin Szturmowy.", req: [{ id: "rifle_assault", qty: 1 }], reward: { credits: 900, xp: 180, rep: 45, item: "ammo556", itemQty: 50 } },
  { id: "q1_t6_4", traderId: "trader6", tier: 1, phase: 2, title: "Pancerze Oddziału", desc: "Dostarcz 1x Kamizelka Kevlar.", req: [{ id: "vest_kevlar", qty: 1 }], reward: { credits: 850, xp: 170, rep: 45, item: "stim_bleedstop", itemQty: 2 } },
  { id: "q1_t6_final", traderId: "trader6", tier: 1, phase: "final", title: "[FINAL TIER 1] Garnizon Straży Sławińskiego", desc: "Dostarcz 1x Karabin Szturmowy i 1x Skrzep patogenu.", req: [{ id: "rifle_assault", qty: 1 }, { id: "pathogen_clot", qty: 1 }], reward: { credits: 2400, xp: 370, rep: 120, item: "armor_exo", itemQty: 1 } },

  // Tier 2
  { id: "q2_t6_1", traderId: "trader6", tier: 2, phase: 1, title: "Eliminacja Zakażonych", desc: "Przekaż 2x Skrzep patogenu.", req: [{ id: "pathogen_clot", qty: 2 }], reward: { credits: 1500, xp: 270, rep: 50, item: "stim_bleedstop", itemQty: 2 } },
  { id: "q2_t6_2", traderId: "trader6", tier: 2, phase: 1, title: "Szturm na Kopalnię", desc: "Dostarcz 50x Amunicja 5.56mm i 1x Topór Strażacki.", req: [{ id: "ammo556", qty: 50 }, { id: "axe_fire", qty: 1 }], reward: { credits: 1800, xp: 310, rep: 60, item: "sniper_dragoon", itemQty: 1 } },
  { id: "q2_t6_3", traderId: "trader6", tier: 2, phase: 2, title: "Oczyszczanie Sektora C", desc: "Dostarcz 3x Skrzep patogenu.", req: [{ id: "pathogen_clot", qty: 3 }], reward: { credits: 2200, xp: 380, rep: 60, item: "armor_exo", itemQty: 1 } },
  { id: "q2_t6_4", traderId: "trader6", tier: 2, phase: 2, title: "Ciężkie Uzbrojenie Straży", desc: "Przekaż 1x Karabin Wyborowy Dragoon.", req: [{ id: "sniper_dragoon", qty: 1 }], reward: { credits: 2600, xp: 440, rep: 60, item: "gold_ingot", itemQty: 1 } },
  { id: "q2_t6_final", traderId: "trader6", tier: 2, phase: "final", title: "[FINAL TIER 2] Operacja Czyste Niebo", desc: "Dostarcz 1x Karabin Wyborowy Dragoon i 2x Skrzep patogenu.", req: [{ id: "sniper_dragoon", qty: 1 }, { id: "pathogen_clot", qty: 2 }], reward: { credits: 5000, xp: 720, rep: 200, item: "gold_ingot", itemQty: 1 } },

  // --- TRADER 7: Profesor Thorne ---
  // Tier 0
  { id: "q0_t7_1", traderId: "trader7", tier: 0, phase: 1, title: "Rękawice Górnicze", desc: "Przekaż 1x Rękawica Wydobywcza do inspekcji.", req: [{ id: "mining_glove", qty: 1 }], reward: { credits: 300, xp: 50, rep: 30, item: "scrap", itemQty: 2 } },
  { id: "q0_t7_2", traderId: "trader7", tier: 0, phase: 1, title: "Próbka Surowca", desc: "Dostarcz 1x Ruda Tytana.", req: [{ id: "ore_titanium", qty: 1 }], reward: { credits: 350, xp: 55, rep: 30, item: "mining_glove", itemQty: 1 } },
  { id: "q0_t7_3", traderId: "trader7", tier: 0, phase: 2, title: "Paliwo Helowe", desc: "Przekaż 1x Hel-3.", req: [{ id: "helium3", qty: 1 }], reward: { credits: 400, xp: 65, rep: 35, item: "fuel_cell", itemQty: 2 } },
  { id: "q0_t7_4", traderId: "trader7", tier: 0, phase: 2, title: "Narzędzia Odwiertu", desc: "Dostarcz 1x Klucz Francuski i 2x Złom.", req: [{ id: "wrench", qty: 1 }, { id: "scrap", qty: 2 }], reward: { credits: 320, xp: 50, rep: 35, item: "mining_glove", itemQty: 1 } },
  { id: "q0_t7_final", traderId: "trader7", tier: 0, phase: "final", title: "[FINAL TIER 0] Stacja Geologiczna Thorne'a", desc: "Dostarcz 2x Ruda Tytana i 1x Hel-3.", req: [{ id: "ore_titanium", qty: 2 }, { id: "helium3", qty: 1 }], reward: { credits: 1200, xp: 180, rep: 80, item: "xenonite_crystal", itemQty: 1 } },

  // Tier 1
  { id: "q1_t7_1", traderId: "trader7", tier: 1, phase: 1, title: "Czysta Ruda Tytana", desc: "Dostarcz 2x Ruda Tytana.", req: [{ id: "ore_titanium", qty: 2 }], reward: { credits: 800, xp: 160, rep: 40, item: "helium3", itemQty: 1 } },
  { id: "q1_t7_2", traderId: "trader7", tier: 1, phase: 1, title: "Reaktor Helowy", desc: "Przekaż 2x Hel-3.", req: [{ id: "helium3", qty: 2 }], reward: { credits: 900, xp: 180, rep: 40, item: "fuel_cell", itemQty: 2 } },
  { id: "q1_t7_3", traderId: "trader7", tier: 1, phase: 2, title: "Kryształ Xenonite", desc: "Dostarcz 1x Kryształ Xenonite.", req: [{ id: "xenonite_crystal", qty: 1 }], reward: { credits: 1100, xp: 210, rep: 45, item: "quantum_core", itemQty: 1 } },
  { id: "q1_t7_4", traderId: "trader7", tier: 1, phase: 2, title: "Głębinowe Próbki", desc: "Przekaż 2x Ruda Tytana i 1x Hel-3.", req: [{ id: "ore_titanium", qty: 2 }, { id: "helium3", qty: 1 }], reward: { credits: 1000, xp: 200, rep: 45, item: "xenonite_crystal", itemQty: 1 } },
  { id: "q1_t7_final", traderId: "trader7", tier: 1, phase: "final", title: "[FINAL TIER 1] Rafineria Prometeusz", desc: "Dostarcz 2x Kryształ Xenonite i 2x Hel-3.", req: [{ id: "xenonite_crystal", qty: 2 }, { id: "helium3", qty: 2 }], reward: { credits: 2600, xp: 400, rep: 120, item: "titan_diamond", itemQty: 1 } },

  // Tier 2
  { id: "q2_t7_1", traderId: "trader7", tier: 2, phase: 1, title: "Diamenty Głębinowe", desc: "Dostarcz 1x Diament Tytana.", req: [{ id: "titan_diamond", qty: 1 }], reward: { credits: 2000, xp: 320, rep: 50, item: "xenonite_crystal", itemQty: 2 } },
  { id: "q2_t7_2", traderId: "trader7", tier: 2, phase: 1, title: "Izotopy Antymaterii", desc: "Przekaż 2x Kryształ Xenonite i 2x Hel-3.", req: [{ id: "xenonite_crystal", qty: 2 }, { id: "helium3", qty: 2 }], reward: { credits: 2200, xp: 350, rep: 60, item: "gold_ingot", itemQty: 1 } },
  { id: "q2_t7_3", traderId: "trader7", tier: 2, phase: 2, title: "Super-Ruda Tytana", desc: "Dostarcz 4x Ruda Tytana i 2x Kryształ Xenonite.", req: [{ id: "ore_titanium", qty: 4 }, { id: "xenonite_crystal", qty: 2 }], reward: { credits: 2600, xp: 420, rep: 60, item: "titan_diamond", itemQty: 1 } },
  { id: "q2_t7_4", traderId: "trader7", tier: 2, phase: 2, title: "Plazma Głębinowa", desc: "Przekaż 2x Diament Tytana.", req: [{ id: "titan_diamond", qty: 2 }], reward: { credits: 3000, xp: 480, rep: 60, item: "gold_ingot", itemQty: 1 } },
  { id: "q2_t7_final", traderId: "trader7", tier: 2, phase: "final", title: "[FINAL TIER 2] Skarb Tytana Thorne'a", desc: "Dostarcz 2x Diament Tytana i 2x Kryształ Xenonite.", req: [{ id: "titan_diamond", qty: 2 }, { id: "xenonite_crystal", qty: 2 }], reward: { credits: 5500, xp: 750, rep: 200, item: "gold_ingot", itemQty: 2 } },

  // --- TRADER 8: Szturmowiec Jax ---
  // Tier 0
  { id: "q0_t8_1", traderId: "trader8", tier: 0, phase: 1, title: "Tajne Pliki", desc: "Dostarcz 1x Chip Danych.", req: [{ id: "data_chip", qty: 1 }], reward: { credits: 300, xp: 50, rep: 30, item: "scrap", itemQty: 2 } },
  { id: "q0_t8_2", traderId: "trader8", tier: 0, phase: 1, title: "Narzędzia Włamania", desc: "Przekaż 1x Łom i 2x Przewody.", req: [{ id: "crowbar", qty: 1 }, { id: "wires", qty: 2 }], reward: { credits: 280, xp: 45, rep: 30, item: "data_chip", itemQty: 1 } },
  { id: "q0_t8_3", traderId: "trader8", tier: 0, phase: 2, title: "Ogniwo Zasilania", desc: "Dostarcz 1x Komórka paliwowa.", req: [{ id: "fuel_cell", qty: 1 }], reward: { credits: 350, xp: 60, rep: 35, item: "circuit", itemQty: 1 } },
  { id: "q0_t8_4", traderId: "trader8", tier: 0, phase: 2, title: "Drogocenny Złom", desc: "Przekaż 3x Złom.", req: [{ id: "scrap", qty: 3 }], reward: { credits: 300, xp: 50, rep: 35, item: "data_chip", itemQty: 1 } },
  { id: "q0_t8_final", traderId: "trader8", tier: 0, phase: "final", title: "[FINAL TIER 0] Czarny Rynek Jaxa", desc: "Dostarcz 2x Chip Danych i 1x Komórka paliwowa.", req: [{ id: "data_chip", qty: 2 }, { id: "fuel_cell", qty: 1 }], reward: { credits: 1250, xp: 190, rep: 80, item: "relic_old_earth", itemQty: 1 } },

  // Tier 1
  { id: "q1_t8_1", traderId: "trader8", tier: 1, phase: 1, title: "Relikt Starej Ziemi", desc: "Dostarcz 1x Starożytny Relikt Ziemi.", req: [{ id: "relic_old_earth", qty: 1 }], reward: { credits: 1000, xp: 200, rep: 40, item: "quantum_core", itemQty: 1 } },
  { id: "q1_t8_2", traderId: "trader8", tier: 1, phase: 1, title: "Kwantowe Szyfry", desc: "Przekaż 1x Kwantowy rdzeń.", req: [{ id: "quantum_core", qty: 1 }], reward: { credits: 1100, xp: 210, rep: 40, item: "gold_ingot", itemQty: 1 } },
  { id: "q1_t8_3", traderId: "trader8", tier: 1, phase: 2, title: "Kolonialne Złoto", desc: "Dostarcz 1x Sztabka Złota Kolonialnego.", req: [{ id: "gold_ingot", qty: 1 }], reward: { credits: 1500, xp: 250, rep: 45, item: "titan_diamond", itemQty: 1 } },
  { id: "q1_t8_4", traderId: "trader8", tier: 1, phase: 2, title: "Cenne Komponenty", desc: "Przekaż 2x Układ scalony i 1x Komórka paliwowa.", req: [{ id: "circuit", qty: 2 }, { id: "fuel_cell", qty: 1 }], reward: { credits: 1200, xp: 220, rep: 45, item: "relic_old_earth", itemQty: 1 } },
  { id: "q1_t8_final", traderId: "trader8", tier: 1, phase: "final", title: "[FINAL TIER 1] Przemyt Sektora Jaxa", desc: "Dostarcz 1x Starożytny Relikt Ziemi i 1x Sztabka Złota.", req: [{ id: "relic_old_earth", qty: 1 }, { id: "gold_ingot", qty: 1 }], reward: { credits: 3000, xp: 450, rep: 120, item: "sniper_dragoon", itemQty: 1 } },

  // Tier 2
  { id: "q2_t8_1", traderId: "trader8", tier: 2, phase: 1, title: "Legenda Dragoona", desc: "Przekaż 1x Karabin Wyborowy Dragoon.", req: [{ id: "sniper_dragoon", qty: 1 }], reward: { credits: 2500, xp: 380, rep: 50, item: "gold_ingot", itemQty: 2 } },
  { id: "q2_t8_2", traderId: "trader8", tier: 2, phase: 1, title: "Diamentowy Skarbiec", desc: "Dostarcz 1x Diament Tytana.", req: [{ id: "titan_diamond", qty: 1 }], reward: { credits: 2800, xp: 420, rep: 60, item: "quantum_core", itemQty: 1 } },
  { id: "q2_t8_3", traderId: "trader8", tier: 2, phase: 2, title: "Złoty Zapas Czarnorynkowy", desc: "Przekaż 2x Sztabka Złota.", req: [{ id: "gold_ingot", qty: 2 }], reward: { credits: 3500, xp: 500, rep: 60, item: "titan_diamond", itemQty: 1 } },
  { id: "q2_t8_4", traderId: "trader8", tier: 2, phase: 2, title: "Ostateczny Relikt", desc: "Dostarcz 2x Starożytny Relikt Ziemi.", req: [{ id: "relic_old_earth", qty: 2 }], reward: { credits: 4000, xp: 550, rep: 60, item: "gold_ingot", itemQty: 2 } },
  { id: "q2_t8_final", traderId: "trader8", tier: 2, phase: "final", title: "[FINAL TIER 2] Władca Czarnego Rynku", desc: "Dostarcz 2x Sztabka Złota, 1x Diament Tytana i 1x Starożytny Relikt.", req: [{ id: "gold_ingot", qty: 2 }, { id: "titan_diamond", qty: 1 }, { id: "relic_old_earth", qty: 1 }], reward: { credits: 8000, xp: 1000, rep: 200, item: "gold_ingot", itemQty: 2 } },
];

// Połączenie zadań głównych i zadań tierowych
const QUESTS = [...MAIN_QUESTS, ...TIER_QUESTS];

if (typeof window !== "undefined") {
  window.TRADERS = TRADERS;
  window.QUESTS = QUESTS;
}
if (typeof globalThis !== "undefined") {
  globalThis.TRADERS = TRADERS;
  globalThis.QUESTS = QUESTS;
}
