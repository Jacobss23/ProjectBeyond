// === SEKCJA: INICJALIZACJA ===
const save = loadSave();
const st = save ? playerStats(save) : null;
const say = termLog;

let curTrader = TRADERS[0].id;
let openModule = null;
let stashView = null;
let loadView = null;
let sellView = null;
let traderView = null;
let traderContainer = null;
const trader = () => TRADERS.find((t) => t.id === curTrader) || TRADERS[0];

if (!save) {
  window.location.replace("index.html");
} else {
  document.addEventListener("DOMContentLoaded", init);
}

function init() {
  mountContainers();
  renderAll();
  say("Terminal schronu aktywny. Wybierz opcję.", "intro");
}

function mountContainers() {
  const common = { onChange: persist };
  stashView = mountGrid($("stash-grid"), save.stash, {
    ...common,
    onSelect: () => renderInvInfo(),
    onQuickMove: (inst) => moveBetween(stashView, loadView, inst),
  });
  loadView = mountGrid($("load-grid"), save.loadout, {
    ...common,
    onSelect: () => renderInvInfo(),
    onQuickMove: (inst) => moveBetween(loadView, stashView, inst),
  });
  sellView = mountGrid($("sell-grid"), save.stash, {
    ...common,
    onSelect: () => renderSellInfo(),
    onQuickMove: () => {},
  });
}

function persist() {
  writeSave(save);
  renderAll();
}

function goTo(screenId) {
  showScreen(screenId);
  setTimeout(renderAll, 450);
}

function goToRaidScreen() {
  goTo("hub-raid");
}
window.goToRaidScreen = goToRaidScreen;

function btn(label, fn, cls = "", disabled = false) {
  const b = document.createElement("button");
  b.textContent = label;
  b.className = `sm ${cls}`;
  b.disabled = disabled;
  b.onclick = fn;
  return b;
}

function row(text, ...buttons) {
  const r = document.createElement("div");
  r.className = "row";
  const label = document.createElement("span");
  label.textContent = text;
  r.appendChild(label);
  const act = document.createElement("span");
  buttons.forEach((b) => act.appendChild(b));
  r.appendChild(act);
  return r;
}

function fill(id, rows, emptyText = "Pusto.") {
  const box = $(id);
  box.innerHTML = "";
  if (!rows.length) box.textContent = emptyText;
  rows.forEach((r) => box.appendChild(r));
}

// === SEKCJA: RENDER GŁÓWNY ===
function renderAll() {
  renderStatus();
  if (typeof renderAnatomyPanel === "function") renderAnatomyPanel($("anatomy-panel"), save);
  renderEquipmentSlots();
  renderInvInfo();
  renderSellInfo();
  renderTrader();
  renderShip();
  renderSkills();
  renderHydro();
  renderModule();
  renderQuests();
  renderRaidList();
  if ($("stash-info")) $("stash-info").textContent = `${usedCells(save.stash)} / ${save.stash.w * save.stash.h}`;
  if ($("load-info")) $("load-info").textContent = `${usedCells(save.loadout)} / ${save.loadout.w * save.loadout.h}`;
  refreshGrids();
}

function renderEquipmentSlots() {
  const box = $("eq-slots-container");
  if (box && typeof renderEquipmentSlotsUI === "function") {
    renderEquipmentSlotsUI(box, false);
  }
}

function renderStatus() {
  $("hub-title").textContent = `Schron - ${save.name}`;
  const lines = [
    ["Planeta", save.planet],
    ["Poziom", `${save.level} (XP ${save.xp} / ${xpForLevel(save.level)})`],
    ["HP", `${save.hp} / ${save.maxHp}`],
    ["Kredyty", `${save.credits} kr`],
    ["Statek", save.kit],
    ["Aktywne stacje", SHIP_MODULES.filter((m) => moduleActive(save, m.id)).map((m) => `${m.id} (${moduleLevel(save, m.id)})`).join(", ") || "brak"],
    ["Cechy", save.traits.length ? save.traits.join(", ") : "brak"],
    ["Rajdy / zgony", `${save.raids} / ${save.deaths}`],
  ];
  const box = $("hub-status");
  box.innerHTML = "";
  lines.forEach(([k, v]) => {
    const d = document.createElement("div");
    d.className = "stat-line";
    const a = document.createElement("span");
    a.textContent = k;
    const b = document.createElement("span");
    b.textContent = v;
    d.append(a, b);
    box.appendChild(d);
  });
}

function infoInto(box, sel, buttons) {
  box.innerHTML = "";
  if (!sel) {
    const p = document.createElement("p");
    p.className = "hint";
    p.textContent = "Kliknij przedmiot, aby zobaczyć szczegóły. Przeciągaj, aby przenosić. R obraca. Dwuklik - szybki transfer.";
    box.appendChild(p);
    return;
  }
  const it = ITEMS[sel.inst.id];
  if (!it) return;
  const h = document.createElement("h3");
  h.textContent = `${it.name}${sel.inst.qty > 1 ? ` x${sel.inst.qty}` : ""}`;
  if (it.quest) {
    const qb = document.createElement("span");
    qb.className = "quest-badge-tag";
    qb.textContent = "PRZEDMIOT FABULARNY // QUEST";
    h.appendChild(qb);
  }
  box.appendChild(h);
  itemStats(sel.inst.id).forEach((t) => {
    const p = document.createElement("p");
    p.textContent = t;
    box.appendChild(p);
  });
  const r = document.createElement("div");
  r.className = "btn-row";
  r.style.marginTop = "8px";
  buttons.forEach((b) => r.appendChild(b));
  box.appendChild(r);
}

function renderInvInfo() {
  const sel = getSelected();
  const inLoad = sel && sel.view === loadView;
  const buttons = [];
  if (sel && (sel.view === stashView || sel.view === loadView)) {
    buttons.push(btn("Obróć (R)", () => rotateSelected(), "ghost"));
    buttons.push(btn(inLoad ? "Do magazynu" : "Do zestawu", () => moveBetween(sel.view, inLoad ? stashView : loadView, sel.inst)));

    const it = ITEMS[sel.inst.id];
    if (it) {
      // Sloty pancerza i broni
      if (it.type === "armor") {
        buttons.push(btn("Załóż Pancerz", () => {
          const ok = equipItem(save, sel.inst.id, "armor", sel.view.cont, sel.inst);
          if (ok) persist();
          else say("Nie można założyć pancerza.", "warn");
        }, "primary-btn"));
      } else if (it.type === "weapon" && it.ammo) {
        buttons.push(btn("Wyposaż: Palna 1", () => {
          const ok = equipItem(save, sel.inst.id, "ranged", sel.view.cont, sel.inst);
          if (ok) persist();
          else say("Nie można wyposażyć broni.", "warn");
        }, "primary-btn"));
        if (typeof hasHolster === "function" && hasHolster(save)) {
          buttons.push(btn("Wyposaż: Palna 2 (Kabura)", () => {
            const ok = equipItem(save, sel.inst.id, "ranged2", sel.view.cont, sel.inst);
            if (ok) persist();
            else say("Nie można wyposażyć drugiej broni.", "warn");
          }, "ghost"));
        }
      } else if (it.type === "weapon" && !it.ammo) {
        buttons.push(btn("Wyposaż: Broń Biała", () => {
          const ok = equipItem(save, sel.inst.id, "melee", sel.view.cont, sel.inst);
          if (ok) persist();
          else say("Nie można wyposażyć broni białej.", "warn");
        }, "primary-btn"));
      }

      // Medykamenty i pożywienie
      const isMedicalOrUsable = it.heal || it.cures || it.buff || it.type === "medical" || ["ration", "bandage", "hemostatic", "bruise_ointment", "splint", "stim_bleedstop", "saturn_cola", "medkit", "morphine", "decontam_kit"].includes(sel.inst.id);
      if (isMedicalOrUsable) {
        buttons.push(btn("Użyj (Leczenie)", () => useMedicalInHideout(sel.inst, sel.view), "primary-btn"));
      }
    }
  }
  infoInto($("inv-info"), sel, buttons);
}

function useMedicalInHideout(inst, view) {
  const itemId = inst.id;
  const it = ITEMS[itemId];
  if (!it) return;

  let used = false;
  let logText = "";

  // 1. Uleczenie efektów ciała / podanie stymulanta
  if (typeof cureBodyEffect === "function") {
    const cureMsg = cureBodyEffect(save, itemId);
    if (cureMsg) {
      used = true;
      logText += cureMsg + ". ";
    }
  }

  // 2. Leczenie HP postaci
  if (it.heal && save.hp < save.maxHp) {
    const healVal = Math.ceil(it.heal * playerStats(save).healMult);
    save.hp = Math.min(save.maxHp, save.hp + healVal);
    used = true;
    logText += `Przywrócono +${healVal} HP (Stan: ${save.hp}/${save.maxHp}). `;
  }

  // 3. Pożywienie
  if (!used && (it.hunger || it.thirst || itemId === "ration")) {
    used = true;
    logText += `Zjedzono / wypito ${it.name}. Zapasy uzupełnione. `;
  }

  if (used) {
    consumeInst(view.cont, inst, 1);
    say(logText || `Użyto: ${it.name}.`, "hit");
    edgeGlow("heal");
    persist();
  } else {
    say(`Brak potrzeby użycia ${it.name} (postać jest w pełni zdrowa).`, "warn");
  }
}

function renderSellInfo() {
  const sel = getSelected();
  const buttons = [];
  if (sel) {
    if (sel.view === traderView) {
      const price = buyPrice(sel.inst.id);
      buttons.push(btn(`Kup 1 (${price} kr)`, () => buyFromTrader(sel.inst), "primary-btn", save.credits < price));
    } else {
      const it = ITEMS[sel.inst.id];
      if (it.quest) buttons.push(btn("Nie na sprzedaż", () => {}, "ghost", true));
      else {
        buttons.push(btn(`Sprzedaj 1 (${sellPrice(sel.inst.id)} kr)`, () => sell(sel.inst, 1)));
        if (sel.inst.qty > 1) buttons.push(btn(`Cały stos (${sellPrice(sel.inst.id) * sel.inst.qty} kr)`, () => sell(sel.inst, sel.inst.qty), "ghost"));
      }
    }
  }
  infoInto($("sell-info"), sel, buttons);
}

// === SEKCJA: // === SEKCJA: HANDLARZE (ZALEŻNI OD KOMUNIKACJI & EKWIPUNEK GRID) ===
function availableTraders() {
  const commLvl = moduleLevel(save, "Komunikacja");
  if (commLvl <= 0) return TRADERS.slice(0, 2);
  if (commLvl === 1) return TRADERS.slice(0, 4);
  if (commLvl === 2) return TRADERS.slice(0, 6);
  return TRADERS; // Wszystkich 8 handlarzy na poziomie 3+
}

function renderTrader() {
  const list = availableTraders();
  if (!list.find((t) => t.id === curTrader)) curTrader = list[0].id;
  const tr = trader();

  const tabs = $("trader-tabs");
  tabs.innerHTML = "";
  list.forEach((t) => {
    const isCur = t.id === curTrader;
    const tLvl = typeof getTraderTier === "function" ? getTraderTier(save, t.id) : 0;
    const b = document.createElement("button");
    b.textContent = `${t.name} [TIER ${tLvl}]`;
    b.className = `sm ${isCur ? "" : "ghost"}`;
    b.style.borderColor = t.color || "#38bdf8";
    if (isCur) {
      b.style.background = t.color || "#38bdf8";
      b.style.color = "#000";
      b.style.fontWeight = "bold";
    } else {
      b.style.color = t.color || "#38bdf8";
    }
    b.onclick = () => selectTrader(t.id);
    tabs.appendChild(b);
  });

  const commLvl = moduleLevel(save, "Komunikacja");
  const discountText = commLvl >= 3 ? " [Czarne Łącze: -10% zniżki na zakupy!]" : "";
  const descEl = $("trader-desc");
  descEl.style.borderLeft = `4px solid ${tr.color || "#38bdf8"}`;
  descEl.style.paddingLeft = "8px";

  const tLvl = typeof getTraderTier === "function" ? getTraderTier(save, tr.id) : 0;
  const repVal = save.traderRep ? save.traderRep[tr.id] || 0 : 0;
  const nextTarget = tLvl === 0 ? 100 : tLvl === 1 ? 300 : 300;

  const repBarHtml = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:6px; font-size:0.85rem; background:rgba(15, 23, 42, 0.7); padding:6px 10px; border-radius:4px; border:1px solid rgba(56, 189, 248, 0.3);">
      <span><strong>Poziom Handlarza:</strong> <span style="color:#fde68a; font-weight:bold;">TIER ${tLvl}</span></span>
      <span><strong>Reputacja:</strong> <span style="color:#38bdf8; font-weight:bold;">${repVal}</span> ${tLvl < 2 ? `/ ${nextTarget} pkt (do Tier ${tLvl + 1})` : "(MAKSYMALNY TIER)"}</span>
    </div>
  `;
  descEl.innerHTML = `<div>${tr.desc}${discountText}</div>${repBarHtml}`;
  $("trader-credits").textContent = `Kredyty: ${save.credits} kr`;

  // Stworzenie kontenera siatki dla handlarza z uwzględnieniem odblokowanego Tieru
  traderContainer = newContainer(8, 6, false);
  let currentStock = [];
  if (Array.isArray(tr.stock)) {
    currentStock = tr.stock;
  } else if (typeof tr.stock === "object") {
    for (let i = 0; i <= tLvl; i++) {
      if (tr.stock[i]) currentStock.push(...tr.stock[i]);
    }
  }

  currentStock.forEach((itemId) => {
    if (ITEMS[itemId]) {
      addToContainer(traderContainer, itemId, 1);
    }
  });

  traderView = mountGrid($("trader-grid"), traderContainer, {
    onSelect: (inst) => {
      renderTraderItemInfo(inst);
    },
    onQuickMove: (inst) => buyFromTrader(inst),
    canMoveIn: () => false,
  });

  // Renderuj zlecenia tego konkretnego handlarza w oknie handlu
  renderTraderQuestsInShop(tr);
}

function renderTraderQuestsInShop(tr) {
  const box = $("trader-quests-list");
  const title = $("trader-quests-title");
  if (!box || !title) return;

  const tLvl = typeof getTraderTier === "function" ? getTraderTier(save, tr.id) : 0;
  title.textContent = `[ZLECENIA HANDLARZA: ${tr.name} // TIER ${tLvl}]`;
  title.style.color = tr.color || "#38bdf8";
  box.innerHTML = "";

  save.quests = save.quests || {};
  autoAcceptQuests();

  const topRow = document.createElement("div");
  topRow.className = "btn-row";
  topRow.style.marginBottom = "8px";
  topRow.appendChild(makeCompletedToggle());
  box.appendChild(topRow);

  const visibleQuests = QUESTS.filter((q) => q.traderId === tr.id).filter((q) => {
    const st = save.quests[q.id] || "available";
    if (st === "completed") return showCompletedQuests;
    return st === "active";
  });

  if (!visibleQuests.length) {
    box.insertAdjacentHTML("beforeend", `<p class="hint">Brak aktywnych zleceń u tego handlarza (Tier ${tLvl}).</p>`);
    return;
  }

  visibleQuests.forEach((q) => {
    const status = save.quests[q.id] || "available";
    box.appendChild(createQuestCard(q, tr, status));
  });
}

// Sortowanie magazynu: układa przedmioty od największych, po typie; łączy stacki.
function sortStash() {
  const st = save.stash;
  const tmp = newContainer(st.w, st.h, false);
  const typeOrder = { weapon: 0, armor: 1, consumable: 2, ammo: 3, tool: 4, valuable: 5, junk: 6 };
  const stacks = {};
  st.items.forEach((o) => (stacks[o.id] = (stacks[o.id] || 0) + o.qty));
  const ids = Object.keys(stacks).sort((a, b) => {
    const ta = typeOrder[ITEMS[a]?.type] ?? 9;
    const tb = typeOrder[ITEMS[b]?.type] ?? 9;
    if (ta !== tb) return ta - tb;
    const [aw, ah] = baseSize(a);
    const [bw, bh] = baseSize(b);
    return bw * bh - aw * ah || a.localeCompare(b);
  });
  for (const id of ids) {
    if (addToContainer(tmp, id, stacks[id]) > 0) {
      return say("Nie udało się posortować – przedmioty nie mieszczą się w ułożonym magazynie.", "warn");
    }
  }
  st.items = tmp.items;
  writeSave(save);
  renderAll();
  say("Magazyn posortowany.", "hit");
}

function renderTraderItemInfo(inst) {
  const box = $("sell-info");
  if (!inst) return renderSellInfo();
  box.innerHTML = "";

  const it = ITEMS[inst.id];
  if (!it) return;

  const h = document.createElement("h3");
  h.textContent = `${it.name}`;
  if (it.quest) {
    const qb = document.createElement("span");
    qb.className = "quest-badge-tag";
    qb.textContent = "QUEST";
    h.appendChild(qb);
  }
  box.appendChild(h);

  itemStats(inst.id).forEach((t) => {
    const p = document.createElement("p");
    p.textContent = t;
    box.appendChild(p);
  });

  const unitPrice = buyPrice(inst.id);
  const maxQty = it.stack || 3;
  let selectedQty = 1;

  const sliderBox = document.createElement("div");
  sliderBox.style.margin = "10px 0";
  sliderBox.style.padding = "8px";
  sliderBox.style.background = "rgba(15, 23, 42, 0.7)";
  sliderBox.style.border = "1px solid rgba(56, 189, 248, 0.3)";
  sliderBox.style.borderRadius = "4px";

  const labelRow = document.createElement("div");
  labelRow.style.display = "flex";
  labelRow.style.justifyContent = "space-between";
  labelRow.style.fontSize = "0.88rem";
  labelRow.style.marginBottom = "6px";

  const qtyTitle = document.createElement("span");
  qtyTitle.textContent = "Wybierz ilość do zakupu:";
  const qtyVal = document.createElement("span");
  qtyVal.style.fontWeight = "bold";
  qtyVal.style.color = "#38bdf8";
  qtyVal.textContent = "1 szt.";
  labelRow.append(qtyTitle, qtyVal);

  const slider = document.createElement("input");
  slider.type = "range";
  slider.min = "1";
  slider.max = maxQty.toString();
  slider.value = "1";
  slider.className = "trader-qty-slider";
  slider.style.width = "100%";

  const buyBtn = btn(`Kup 1 szt. (${unitPrice} kr)`, () => buyFromTrader(inst, selectedQty), "primary-btn", save.credits < unitPrice);

  slider.oninput = () => {
    selectedQty = parseInt(slider.value, 10);
    qtyVal.textContent = `${selectedQty} szt.`;
    const totalPrice = unitPrice * selectedQty;
    buyBtn.textContent = `Kup ${selectedQty} szt. (${totalPrice} kr)`;
    buyBtn.disabled = save.credits < totalPrice;
  };

  sliderBox.append(labelRow, slider);
  box.appendChild(sliderBox);

  const row = document.createElement("div");
  row.className = "btn-row";
  row.appendChild(buyBtn);
  box.appendChild(row);
}

const buyPrice = (id) => {
  const commLvl = moduleLevel(save, "Komunikacja");
  const mult = trader().buyMult * (commLvl >= 3 ? 0.9 : 1.0);
  return Math.ceil(ITEMS[id].value * mult);
};
const sellPrice = (id) => Math.floor(ITEMS[id].value * trader().sellMult);

function selectTrader(id) {
  curTrader = id;
  say(`Handlarz: ${trader().name}.`);
  renderTrader();
  renderSellInfo();
}

function buyFromTrader(inst, qty = 1) {
  if (!inst) return;
  const id = inst.id;
  const price = buyPrice(id) * qty;
  if (save.credits < price) return say("Za mało kredytów.", "warn");
  save.credits -= price;
  addToContainer(save.stash, id, qty);
  say(`Kupiono: ${ITEMS[id].name}${qty > 1 ? ` x${qty}` : ""} (-${price} kr).`, "hit");
  edgeGlow("loot");
  persist();
}

function sell(inst, qty) {
  const id = inst.id;
  const gain = sellPrice(id) * qty;
  consumeInst(save.stash, inst, qty);
  save.credits += gain;
  say(`Sprzedano handlarzowi: ${ITEMS[id].name} x${qty} (+${gain} kr).`, "hit");
  edgeGlow("heal");
  persist();
}

// === SEKCJA: 7 MODUŁÓW SCHRONU (ULEPSZANIE) ===
function renderShip() {
  const box = $("ship-list");
  box.innerHTML = "";

  SHIP_MODULES.forEach((m) => {
    const curLvl = moduleLevel(save, m.id);
    const isMax = curLvl >= m.maxLevel;
    const curLevelDef = m.levels.find((l) => l.level === curLvl) || m.levels[0];
    const nextLevelDef = isMax ? null : m.levels.find((l) => l.level === curLvl + 1);

    const p = document.createElement("div");
    p.className = "ship-module-card";

    const h = document.createElement("h3");
    h.textContent = `${m.name} [Poziom ${curLvl}/${m.maxLevel}]`;

    const sub = document.createElement("p");
    sub.className = "hint";
    sub.textContent = `${curLevelDef.title}: ${curLevelDef.desc}`;

    p.append(h, sub);

    const costDiv = document.createElement("div");
    costDiv.style.margin = "8px 0";
    costDiv.style.fontSize = "0.9rem";

    let canUpgrade = false;
    if (nextLevelDef) {
      const hasCreds = save.credits >= nextLevelDef.cost;
      const credText = `${nextLevelDef.cost} kr (masz: ${save.credits})`;

      const reqItems = nextLevelDef.items.map(([itId, need]) => {
        const have = countItem(save.stash, itId);
        const name = ITEMS[itId] ? ITEMS[itId].name : itId;
        const ok = have >= need;
        return { ok, str: `${name}: ${have}/${need}` };
      });

      const allItemsOk = reqItems.every((r) => r.ok);
      canUpgrade = hasCreds && allItemsOk;

      const itemsStr = reqItems.map((r) => `<span style="color:${r.ok ? '#86efac' : '#f87171'}">${r.str}</span>`).join(" | ");
      costDiv.innerHTML = `<strong>Kolejny poziom (${nextLevelDef.title}):</strong> ${nextLevelDef.desc}<br/>Koszt: <span style="color:${hasCreds ? '#86efac' : '#f87171'}">${credText}</span>${itemsStr ? ` | Wymagane: ${itemsStr}` : ""}`;
    } else {
      costDiv.innerHTML = `<span style="color:#a78bfa; font-weight: bold;">MAKSYMALNY POZIOM STACJI</span>`;
    }
    p.appendChild(costDiv);

    const r = document.createElement("div");
    r.className = "btn-row";

    if (m.id === "Crafting" || m.id === "Medstation") {
      r.appendChild(btn("Otwórz stację", () => openMod(m.id), "", curLvl === 0));
    } else if (m.id === "Hydroponika") {
      r.appendChild(btn("Przejdź do farmy", () => goTo("hub-hydro"), "", curLvl === 0));
    }

    if (!isMax && nextLevelDef) {
      r.appendChild(btn(`Ulepsz na poz. ${curLvl + 1}`, () => upgradeModule(m.id), "", !canUpgrade));
    }

    p.appendChild(r);
    box.appendChild(p);
  });
}

function upgradeModule(modId) {
  const m = SHIP_MODULES.find((x) => x.id === modId);
  if (!m) return;
  const curLvl = moduleLevel(save, m.id);
  if (curLvl >= m.maxLevel) return;
  const next = m.levels.find((l) => l.level === curLvl + 1);
  if (!next) return;

  if (save.credits < next.cost) return say("Za mało kredytów na ulepszenie.", "warn");
  const missingItem = next.items.find(([id, qty]) => countItem(save.stash, id) < qty);
  if (missingItem) return say(`Brak wystarczającej ilości: ${ITEMS[missingItem[0]]?.name || missingItem[0]}.`, "warn");

  save.credits -= next.cost;
  next.items.forEach(([id, qty]) => removeById(save.stash, id, qty));

  save.ship.modules[modId].level = curLvl + 1;
  save.ship.modules[modId].active = true;

  if (modId === "Stash") {
    const dim = stashSizeForLevel(save.ship.modules.Stash.level);
    save.stash.w = dim[0];
    save.stash.h = dim[1];
    mountContainers();
  }

  grantSkillXp(save, "inzynieria", 35);
  say(`Ulepszono stację: ${m.name} -> Poziom ${curLvl + 1}! (+35 XP Inżynieria).`, "hit");
  edgeGlow("tech");
  persist();
}

// === SEKCJA: UMIEJĘTNOŚCI (0-15) ===
function renderSkills() {
  const box = $("skills-list");
  if (!box || typeof SKILLS === "undefined") return;
  box.innerHTML = "";

  Object.values(SKILLS).forEach((sk) => {
    const cur = save.skills[sk.id] || { level: 0, xp: 0 };
    const maxCap = save.maxSkillCap || 15;
    const isMax = cur.level >= maxCap;
    const req = sk.xpFormula(cur.level);
    const pct = isMax ? 100 : Math.min(100, Math.floor((cur.xp / req) * 100));

    const p = document.createElement("div");
    p.className = "panel";
    p.style.textAlign = "left";

    const titleRow = document.createElement("div");
    titleRow.style.display = "flex";
    titleRow.style.justifyContent = "space-between";
    titleRow.style.alignItems = "center";
    titleRow.innerHTML = `<strong>${sk.name}</strong> <span style="color:var(--accent-glow)">Poz. ${cur.level}/${maxCap}</span>`;

    const desc = document.createElement("p");
    desc.className = "hint";
    desc.style.margin = "4px 0";
    desc.textContent = sk.desc;

    const barOuter = document.createElement("div");
    barOuter.style.background = "rgba(0,0,0,0.5)";
    barOuter.style.border = "1px solid var(--btn-border)";
    barOuter.style.borderRadius = "4px";
    barOuter.style.height = "12px";
    barOuter.style.overflow = "hidden";
    barOuter.style.position = "relative";
    barOuter.style.marginTop = "6px";

    const barInner = document.createElement("div");
    barInner.style.background = isMax ? "#22c55e" : "linear-gradient(90deg, #3b82f6, #8b5cf6)";
    barInner.style.height = "100%";
    barInner.style.width = `${pct}%`;
    barOuter.appendChild(barInner);

    const xpLabel = document.createElement("div");
    xpLabel.style.fontSize = "0.75rem";
    xpLabel.style.color = "#94a3b8";
    xpLabel.style.marginTop = "3px";
    xpLabel.textContent = isMax ? "MISTRZOSTWO (MAX)" : `Postęp: ${cur.xp} / ${req} XP (${pct}%)`;

    p.append(titleRow, desc, barOuter, xpLabel);
    box.appendChild(p);
  });
}

// === SEKCJA: HYDROPONIKA (FARMA ŻYWNOŚCI I WODA) ===
function renderHydro() {
  const box = $("hydro-status");
  if (!box) return;
  const lvl = moduleLevel(save, "Hydroponika");

  if (lvl === 0) {
    box.innerHTML = `<p style="color:#f87171">Hydroponika jest nieaktywna (poziom 0). Ulepsz moduł w sekcji <em>Moduły bazy</em>, aby rozpocząć uprawę pożywienia i produkcję czystej wody.</p>`;
    return;
  }

  const productionRation = lvl;
  const productionWater = Math.ceil(lvl / 2);
  const curFood = save.hydroponics?.food ?? 1;
  const curWater = save.hydroponics?.water ?? 1;

  box.innerHTML = `
    <div style="display:flex; justify-content:space-around; align-items:center; margin-bottom:12px;">
      <div style="text-align:center;">
        <span class="term-badge" style="display:inline-block; margin-bottom:4px;">[ŻYWNOŚĆ]</span><br/>
        <strong>Gotowe racje:</strong> ${curFood} szt.
      </div>
      <div style="text-align:center;">
        <span class="term-badge" style="display:inline-block; margin-bottom:4px;">[WODA PITNA]</span><br/>
        <strong>Czysta woda:</strong> ${curWater} szt.
      </div>
      <div style="text-align:center;">
        <span class="term-badge" style="display:inline-block; margin-bottom:4px;">[WYDAJNOŚĆ]</span><br/>
        <strong>Produkcja:</strong> ${productionRation} racji / cykl
      </div>
    </div>
    <p class="hint">Farma działa w trybie zamkniętej biosfery. Zbieraj zapasy regularnie, aby zaopatrzyć się na wyprawy do stref skażonych.</p>
  `;
}

function harvestHydro() {
  const lvl = moduleLevel(save, "Hydroponika");
  if (lvl === 0) return say("Hydroponika nieaktywna. Najpierw ulepsz moduł.", "warn");

  const curFood = save.hydroponics?.food ?? 1;
  const curWater = save.hydroponics?.water ?? 1;

  if (curFood <= 0 && curWater <= 0) {
    return say("Brak plonów gotowych do zbioru. Odczekaj kolejny cykl.", "warn");
  }

  let gathered = 0;
  if (curFood > 0) {
    addToContainer(save.stash, "ration", curFood);
    gathered += curFood;
  }
  if (curWater > 0) {
    addToContainer(save.stash, "bandage", curWater);
    gathered += curWater;
  }

  save.hydroponics.food = 0;
  save.hydroponics.water = 0;
  save.hydroponics.lastCheck = Date.now();

  grantSkillXp(save, "metabolizm", 15);
  say(`Zebrano plony: ${gathered} zapasów przeniesiono do magazynu! (+15 XP Metabolizm).`, "hit");
  edgeGlow("loot");
  persist();
}

// === SEKCJA: WNĘTRZE MODUŁU (CRAFTING & MEDSTATION) ===
function openMod(id) {
  openModule = id;
  say(`Moduł: ${id}.`, "tip");
  renderModule();
  goTo("hub-module");
}

function renderModule() {
  const m = SHIP_MODULES.find((x) => x.id === openModule);
  if (!m) return;
  $("module-title").textContent = `${m.name} (Poz. ${moduleLevel(save, m.id)})`;
  $("module-desc").textContent = m.desc;

  const curLvl = moduleLevel(save, m.id);
  const list = RECIPES.filter((r) => r.module === m.id || (m.id === "Crafting" && r.module === "Warsztat") || (m.id === "Medstation" && r.module === "Medyczny"));

  const rows = list.map((r) => {
    const minLvl = r.minLevel || 1;
    const lvlOk = curLvl >= minLvl;
    const needs = r.in.map(([id, q]) => `${ITEMS[id]?.name || id} x${q}`).join(", ");
    const matsOk = r.in.every(([id, q]) => countItem(save.stash, id) >= q);

    const btnLabel = !lvlOk ? `Wymaga poz. ${minLvl}` : "Wytwórz";
    return row(`${r.name} (${needs})`, btn(btnLabel, () => craft(r.id), "", !lvlOk || !matsOk));
  });

  fill("module-recipes", rows, "[Brak receptur dla tej stacji]");
}

function craft(recipeId) {
  const r = RECIPES.find((x) => x.id === recipeId);
  if (!r) return;
  if (!r.in.every(([id, q]) => countItem(save.stash, id) >= q)) return say("Brak materiałów w magazynie.", "warn");

  r.in.forEach(([id, q]) => removeById(save.stash, id, q));
  addToContainer(save.stash, r.out[0], r.out[1]);

  grantSkillXp(save, "inzynieria", 15);
  say(`Wytworzono: ${r.name} (+15 XP Inżynieria).`, "hit");
  edgeGlow("tech");
  persist();
}

// === SEKCJA: RAJDY & SAFE SYSTEM RADAR ===
// === SEKCJA: MAPA ROZRAIDU – NAWIGACJA: GALAKTYKI → UKŁADY → UKŁAD SŁONECZNY → TYTAN ===
const RAID_TITAN_NODES = [
  { id: "titan_dome", x: 330, y: 92, label: "Kopuła Nowy Ereb" },
  { id: "titan_mines", x: 470, y: 300, label: "Szyby Prometeusz" },
  { id: "titan_archive", x: 170, y: 306, label: "Archiwum" },
];

function mapLockReason(id) {
  const m = MAPS[id];
  if (id === "vega" && moduleLevel(save, "Silniki") < 1) return "Wymaga: Napęd Statku poz. 1";
  if (m.unlock && getTraderTier(save, m.unlock.trader) < m.unlock.tier) {
    return "Wymaga: zaufania handlarza, Tier " + m.unlock.tier;
  }
  return null;
}

// Wróć na ekranie rajdu: o jeden poziom mapy w górę (menu tylko z najwyższego poziomu)
function raidMapBack() {
  if (window.rmapBackFn) return window.rmapBackFn();
  goTo("hub-main");
}
window.raidMapBack = raidMapBack;

function renderRaidList() {
  const box = $("raid-list");
  if (!box) return;
  box.innerHTML = "";
  const wrap = document.createElement("div");
  wrap.className = "rmap-view";
  box.appendChild(wrap);
  showGalaxies(wrap);
}

// Wspólna rama widoku: tło gwiazd, nagłówek z „wstecz”, treść, panel szczegółów
function rmapSetView(wrap, opts) {
  window.rmapBackFn = opts.back ? opts.back.fn : null;
  const back = opts.back
    ? `<button class="sm ghost" data-back>← ${opts.back.label}</button>`
    : "<span></span>";
  wrap.innerHTML = `
    <div class="rmap-stars"></div>
    <div class="rmap-back">${back}<span class="rmap-title">${opts.title}</span></div>
    ${opts.body}
    <div class="rmap-detail" id="rmap-detail">${opts.detail || "<p>Wybierz cel na mapie.</p>"}</div>`;
  addRmapStars(wrap);
  wrap.classList.remove("rmap-enter");
  void wrap.offsetWidth;
  wrap.classList.add("rmap-enter");
  if (opts.back) wrap.querySelector("[data-back]").addEventListener("click", opts.back.fn);
  if (opts.tutorial && !save.tutorialDone) {
    // samouczek zawsze dostępny z pierwszego widoku, dopóki nie jest ukończony
  }
  wrap.querySelectorAll("[data-map]").forEach((el) => el.addEventListener("click", () => showMapDetail(el.dataset.map)));
  wrap.querySelectorAll("[data-go]").forEach((el) => el.addEventListener("click", () => RMAP_GO[el.dataset.go](wrap)));
}

function addRmapStars(wrap) {
  const field = wrap.querySelector(".rmap-stars");
  if (!field) return;
  for (let i = 0; i < 70; i++) {
    const s = document.createElement("i");
    s.style.left = Math.random() * 100 + "%";
    s.style.top = Math.random() * 100 + "%";
    s.style.animationDelay = (Math.random() * 3).toFixed(2) + "s";
    s.style.width = s.style.height = (Math.random() < 0.2 ? 3 : 2) + "px";
    field.appendChild(s);
  }
}

// Spirala galaktyki (rzut ukośny)
function spiralD(cx, cy, arms, turns, rMax) {
  let d = "";
  for (let a = 0; a < arms; a++) {
    const off = (a * 2 * Math.PI) / arms;
    for (let i = 0; i <= 60; i++) {
      const t = i / 60;
      const ang = off + t * turns * 2 * Math.PI;
      const r = rMax * t;
      const x = cx + r * Math.cos(ang);
      const y = cy + r * Math.sin(ang) * 0.5;
      d += (i === 0 ? "M" : "L") + x.toFixed(1) + " " + y.toFixed(1) + " ";
    }
  }
  return d;
}

function galaxyDots(cx, cy, rMax, n) {
  let s = "";
  for (let i = 0; i < n; i++) {
    const r = rMax * Math.pow(Math.random(), 0.6);
    const a = Math.random() * Math.PI * 2;
    const x = (cx + r * Math.cos(a)).toFixed(1);
    const y = (cy + r * Math.sin(a) * 0.5).toFixed(1);
    s += `<circle cx="${x}" cy="${y}" r="${(Math.random() * 1.6 + 0.6).toFixed(1)}"/>`;
  }
  return s;
}

// --- Poziom 1: galaktyki ---
function showGalaxies(wrap) {
  rmapSetView(wrap, {
    title: "Galaktyki",
    body: `
      <svg class="rmap-svg" viewBox="0 0 640 300" role="img" aria-label="Galaktyki">
        <g class="galaxy" data-go="milky">
          <circle class="gal-hit" cx="170" cy="150" r="150"/>
          <g class="galaxy-spin" style="transform-origin:170px 150px">
            <path class="arm" d="${spiralD(170, 150, 2, 1.8, 130)}"/>
            <g class="dots">${galaxyDots(170, 150, 130, 140)}</g>
          </g>
          <circle class="gal-core" cx="170" cy="150" r="14"/>
          <text x="170" y="292">Droga Mleczna</text>
        </g>
        <g class="galaxy" data-go="whirl">
          <circle class="gal-hit" cx="470" cy="150" r="150"/>
          <g class="galaxy-spin reverse" style="transform-origin:470px 150px">
            <path class="arm red" d="${spiralD(470, 150, 2, 2.4, 110)}"/>
            <g class="dots red">${galaxyDots(470, 150, 110, 110)}</g>
          </g>
          <circle class="gal-core red" cx="470" cy="150" r="12"/>
          <text x="470" y="292">Wirlpool (M51)</text>
        </g>
      </svg>`,
    detail: "<p>Wybierz galaktykę, aby zbliżyć się do jej układów gwiezdnych.</p>",
  });
  // samouczek pozostaje dostępny na pierwszym poziomie
  {
    const det = wrap.querySelector("#rmap-detail");
    det.insertAdjacentHTML("afterbegin", '<button class="sm ghost" data-map="tutorial" style="margin-bottom:8px;">Samouczek</button>');
    wrap.querySelector('[data-map="tutorial"]').addEventListener("click", () => showMapDetail("tutorial"));
  }
}

// --- Poziom 2: Droga Mleczna – układy gwiezdne ---
function showMilky(wrap) {
  rmapSetView(wrap, {
    back: { label: "Galaktyki", fn: () => showGalaxies(wrap) },
    title: "Droga Mleczna",
    body: `
      <svg class="rmap-svg" viewBox="0 0 640 320" role="img" aria-label="Droga Mleczna">
        <path class="arm faint" d="${spiralD(320, 160, 2, 1.4, 290)}"/>
        <g class="star" data-go="sol" transform="translate(250 150)">
          <circle class="star-hit" r="26"/><circle class="star-core yellow" r="10"/><text y="34">Słońce · Sol</text>
        </g>
        <g class="star" data-go="vega" transform="translate(430 96)">
          <circle class="star-hit" r="26"/><circle class="star-core blue" r="9"/><text y="32">Wega</text>
        </g>
        <g class="star" data-go="tau" transform="translate(380 236)">
          <circle class="star-hit" r="26"/><circle class="star-core orange" r="9"/><text y="32">Tau Ceti</text>
        </g>
      </svg>`,
    detail: "<p>Trzy zbadane układy. Wybierz gwiazdę, aby wejść do jej układu.</p>",
  });
}

function showWhirl(wrap) {
  rmapSetView(wrap, {
    back: { label: "Galaktyki", fn: () => showGalaxies(wrap) },
    title: "Wirlpool (M51)",
    body: `
      <svg class="rmap-svg" viewBox="0 0 640 260" role="img" aria-label="Wirlpool">
        <g class="galaxy-spin reverse" style="transform-origin:320px 130px">
          <path class="arm faint red" d="${spiralD(320, 130, 2, 2.4, 230)}"/>
        </g>
      </svg>`,
    detail: "<h3>Brak danych</h3><p>Ta galaktyka nie została jeszcze zbadana. Układy gwiezdne są poza zasięgiem.</p>",
  });
}

// --- Poziom 3: układ słoneczny (Sol) – wszystkie planety; nazwy po najechaniu, grywalne zawsze ---
// Orbity spowolnione o 70% (prędkość 30%) – czasy trwania mnożone przez ORBIT_SLOW.
const ORBIT_SLOW = 1 / 0.3;

function ellipsePath(cx, cy, rx, ry) {
  return `M${cx + rx} ${cy} A${rx} ${ry} 0 1 0 ${cx - rx} ${cy} A${rx} ${ry} 0 1 0 ${cx + rx} ${cy}`;
}

// Start orbity z różnego miejsca: ujemny begin = przesunięcie fazy
function orbitBegin(i, dur) {
  return `-${(((i * 0.618) % 1) * dur).toFixed(1)}s`;
}

const SOL_PLANETS = [
  { name: "Merkury", rx: 62, r: 2.5, color: "#a8a29e", dur: 24 },
  { name: "Wenus", rx: 82, r: 3.5, color: "#fde68a", dur: 34 },
  { name: "Ziemia", rx: 108, r: 4.2, ruined: true, dur: 46 },
  { name: "Mars", rx: 134, r: 3.2, color: "#f87171", dur: 60 },
  { name: "Jowisz", rx: 168, r: 9, color: "#fdba74", dur: 110 },
  { name: "Saturn", rx: 200, r: 7.5, color: "#fde68a", dur: 140, rings: true, moon: true },
  { name: "Uran", rx: 230, r: 6, color: "#67e8f9", dur: 180 },
  { name: "Neptun", rx: 260, r: 6.5, color: "#60a5fa", dur: 220 },
];

function ruinedEarthSvg() {
  return `<g class="ruined-earth">
    <circle r="4.8" class="earth-body"/>
    <path class="cracks" d="M-3 -2 L0 0 L-1.5 3 M1.5 -3.5 L2.5 -0.5 L1 1.5"/>
    <circle class="lights" cx="1.6" cy="-1.4" r="0.7"/>
    <ellipse class="debris" rx="9" ry="3"/>
  </g>`;
}

// Nazwa planety: po najechaniu (lub zawsze, gdy grywalna)
function planetName(text, y, always) {
  return `<text class="pname${always ? " always" : ""}" y="${y}">${text}</text>`;
}

function showSol(wrap) {
  const cx = 320;
  const cy = 190;
  const ex = { x: 60 + Math.random() * 520, y: 50 + Math.random() * 280 };
  const orbits = SOL_PLANETS.map((p) => `<ellipse class="orbit faint" cx="${cx}" cy="${cy}" rx="${p.rx}" ry="${p.rx * 0.5}"/>`).join("");
  const planets = SOL_PLANETS.map((p, i) => {
    const dur = (p.dur * ORBIT_SLOW).toFixed(0);
    const body = p.ruined ? ruinedEarthSvg() : `<circle r="${p.r}" fill="${p.color}" class="planet-dot"/>`;
    const rings = p.rings ? `<ellipse class="saturn-ring" rx="${(p.r * 2.4).toFixed(1)}" ry="${(p.r * 0.7).toFixed(1)}"/>` : "";
    const moon = p.moon
      ? `<g data-go="titan" class="moon" pointer-events="all">
            <animateMotion dur="${(22 * ORBIT_SLOW).toFixed(0)}s" repeatCount="indefinite" path="${ellipsePath(0, 0, 42, 42)}"/>
            <circle class="moon-hit" r="14" pointer-events="all"/>
            <circle class="moon-body" r="5"/>
            <text y="-12" class="pname always">Tytan</text>
          </g>`
      : "";
    return `<g class="pl">
        <animateMotion dur="${dur}s" begin="${orbitBegin(i, Number(dur))}" repeatCount="indefinite" path="${ellipsePath(cx, cy, p.rx, p.rx * 0.5)}"/>
        <circle class="hit" r="${Math.max(9, p.r + 6)}" pointer-events="all"/>
        ${body}${rings}${moon}
        ${planetName(p.name, -(p.r + 8), false)}
      </g>`;
  }).join("");
  rmapSetView(wrap, {
    back: { label: "Droga Mleczna", fn: () => showMilky(wrap) },
    title: "Układ Słoneczny",
    body: `
      <svg class="rmap-svg sol" viewBox="0 0 640 380" role="img" aria-label="Układ Słoneczny">
        <defs>
          <radialGradient id="gSun" cx="50%" cy="50%" r="50%">
            <stop offset="0" stop-color="#fffbeb"/><stop offset="0.5" stop-color="#fde047"/><stop offset="1" stop-color="#f59e0b" stop-opacity="0"/>
          </radialGradient>
        </defs>
        ${orbits}
        <circle class="sun-glow" cx="${cx}" cy="${cy}" r="46" fill="url(#gSun)"/>
        <circle class="sun" cx="${cx}" cy="${cy}" r="20"/>
        <text x="${cx}" y="${cy + 38}" class="sun-label">Słońce</text>
        ${planets}
        <g class="exodus" data-go="exodus" transform="translate(${ex.x.toFixed(0)} ${ex.y.toFixed(0)})">
          <circle class="exodus-hit" r="20"/>
          <circle class="exodus-pulse" r="14"/>
          <rect x="-9" y="-4" width="18" height="8" rx="2" class="exodus-body"/>
          <text y="-22" class="pname always">Exodus Prime</text>
        </g>
      </svg>`,
    detail: "<p>Osiem planet krąży wokół Słońca. Najedź na planetę, by zobaczyć jej nazwę. Kliknij Tytana lub Exodus Prime.</p>",
  });
}

// --- Poziom 3: układ Wega (stacja Wega-7 + planety z nazwami po najechaniu) ---
function showVega(wrap) {
  const cx = 320;
  const cy = 150;
  const specs = [
    { name: "Wega I", rx: 70, r: 3, dur: 30 },
    { name: "Wega II", rx: 110, r: 4.5, dur: 55 },
    { name: "Wega III", rx: 150, r: 5.5, dur: 80 },
    { name: "Wega IV", rx: 240, r: 8, dur: 120 },
  ];
  const orbits = specs.map((s) => `<ellipse class="orbit faint" cx="${cx}" cy="${cy}" rx="${s.rx}" ry="${s.rx * 0.5}"/>`).join("");
  const planets = specs
    .map((s, i) => {
      const dur = (s.dur * ORBIT_SLOW).toFixed(0);
      return `<g class="pl">
        <animateMotion dur="${dur}s" begin="${orbitBegin(i, Number(dur))}" repeatCount="indefinite" path="${ellipsePath(cx, cy, s.rx, s.rx * 0.5)}"/>
        <circle class="hit" r="${Math.max(9, s.r + 6)}" pointer-events="all"/>
        <circle r="${s.r}" fill="#94a3b8" class="planet-dot"/>
        ${planetName(s.name, -(s.r + 8), false)}
      </g>`;
    })
    .join("");
  rmapSetView(wrap, {
    back: { label: "Droga Mleczna", fn: () => showMilky(wrap) },
    title: "Układ Wegi",
    body: `
      <svg class="rmap-svg" viewBox="0 0 640 300" role="img" aria-label="Układ Wegi">
        <defs>
          <radialGradient id="gVega" cx="50%" cy="50%" r="50%">
            <stop offset="0" stop-color="#f0f9ff"/><stop offset="0.5" stop-color="#7dd3fc"/><stop offset="1" stop-color="#0ea5e9" stop-opacity="0"/>
          </radialGradient>
        </defs>
        ${orbits}
        <circle class="sun-glow" cx="${cx}" cy="${cy}" r="60" fill="url(#gVega)"/>
        <circle class="sun" cx="${cx}" cy="${cy}" r="20" style="fill:#e0f2fe;stroke:#38bdf8"/>
        <text x="${cx}" y="${cy + 36}" class="sun-label">Wega</text>
        ${planets}
        <g pointer-events="none">
          <animateMotion dur="${(60 * ORBIT_SLOW).toFixed(0)}s" repeatCount="indefinite" path="${ellipsePath(cx, cy, 205, 102)}"/>
          <g data-map="vega" class="station" pointer-events="all">
            <circle class="ring" r="16"/><circle r="9" fill="#38bdf8"/><text y="28" class="pname always">Wega-7</text>
          </g>
        </g>
      </svg>`,
    detail: "<p>Stacja badawcza krąży wokół Wegi. Najedź na planetę, by zobaczyć jej nazwę.</p>",
  });
}

// --- Poziom 3: układ Tau Ceti (planety z nazwami po najechaniu) ---
function showTau(wrap) {
  const cx = 320;
  const cy = 130;
  const specs = [
    { name: "Tau Ceti e", rx: 60, r: 3, dur: 26 },
    { name: "Tau Ceti f", rx: 100, r: 4.5, dur: 40 },
    { name: "Tau Ceti g", rx: 140, r: 6, dur: 58 },
    { name: "Tau Ceti h", rx: 190, r: 4, dur: 84 },
  ];
  const orbits = specs.map((s) => `<ellipse class="orbit faint" cx="${cx}" cy="${cy}" rx="${s.rx}" ry="${(s.rx * 0.45).toFixed(1)}"/>`).join("");
  const planets = specs
    .map((s, i) => {
      const dur = (s.dur * ORBIT_SLOW).toFixed(0);
      const ry = (s.rx * 0.45).toFixed(1);
      return `<g class="pl">
        <animateMotion dur="${dur}s" begin="${orbitBegin(i, Number(dur))}" repeatCount="indefinite" path="${ellipsePath(cx, cy, s.rx, ry)}"/>
        <circle class="hit" r="${Math.max(9, s.r + 6)}" pointer-events="all"/>
        <circle r="${s.r}" fill="#fdba74" class="planet-dot"/>
        ${planetName(s.name, -(s.r + 8), false)}
      </g>`;
    })
    .join("");
  rmapSetView(wrap, {
    back: { label: "Droga Mleczna", fn: () => showMilky(wrap) },
    title: "Układ Tau Ceti",
    body: `
      <svg class="rmap-svg" viewBox="0 0 640 260" role="img" aria-label="Układ Tau Ceti">
        ${orbits}
        <circle class="sun-glow" cx="${cx}" cy="${cy}" r="60" fill="#fdba74" style="opacity:.22"/>
        <circle class="sun" cx="${cx}" cy="${cy}" r="20" style="fill:#fdba74;stroke:#ea580c"/>
        <text x="${cx}" y="${cy + 36}" class="sun-label">Tau Ceti</text>
        ${planets}
      </svg>`,
    detail: "<h3>Brak zbadanych obiektów</h3><p>Układ ma kilka planet, ale żadna nie jest jeszcze dostępna do lądowania.</p>",
  });
}

// --- Poziom 4: Tytan (schemat przekroju) ---
function showTitan(wrap) {
  rmapSetView(wrap, {
    back: { label: "Układ Słoneczny", fn: () => showSol(wrap) },
    title: "Schemat Tytana",
    body: `
      <svg class="rmap-svg" viewBox="0 0 640 380" role="img" aria-label="Schemat przekroju Tytana">
        <defs>
          <linearGradient id="gSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#0c1a2e"/><stop offset="1" stop-color="#1e293b"/>
          </linearGradient>
          <linearGradient id="gCrust" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#78350f"/><stop offset="1" stop-color="#1c0f05"/>
          </linearGradient>
        </defs>
        <rect x="0" y="0" width="640" height="130" fill="url(#gSky)"/>
        <rect x="0" y="130" width="640" height="250" fill="url(#gCrust)"/>
        <path class="surface" d="M0 130 Q320 110 640 130"/>
        <path class="dome dome-glow" d="M250 124 Q330 18 410 124"/>
        <path class="link flow" d="M360 126 Q420 200 470 300"/>
        <path class="link flow" d="M300 126 Q220 220 170 306"/>
        <path class="link faint flow" d="M170 306 Q320 350 470 300"/>
        ${RAID_TITAN_NODES.map((n) => {
          const lock = mapLockReason(n.id);
          return `
          <g class="mnode${lock ? " locked" : ""}" data-map="${n.id}" transform="translate(${n.x} ${n.y})">
            <circle class="pulse" r="18"/>
            <circle class="core" r="9"/>
            <text y="32">${n.label}</text>
            ${lock ? '<text y="48" class="lock-tag">🔒</text>' : ""}
          </g>`;
        }).join("")}
      </svg>`,
    detail: "<p>Wybierz lokację na schemacie.</p>",
  });
}

function showExodus(wrap) {
  const det = wrap.querySelector("#rmap-detail");
  det.innerHTML = "<h3>Exodus Prime</h3><p>Statek-planeta. Na razie nic tu nie ma – nie ma jeszcze żadnych lokacji.</p>";
  det.classList.remove("rmap-enter");
  void det.offsetWidth;
  det.classList.add("rmap-enter");
}

const RMAP_GO = {
  milky: (w) => showMilky(w),
  whirl: (w) => showWhirl(w),
  sol: (w) => showSol(w),
  vega: (w) => showVega(w),
  tau: (w) => showTau(w),
  titan: (w) => showTitan(w),
  exodus: (w) => showExodus(w),
};

function showMapDetail(id) {
  const det = document.getElementById("rmap-detail");
  if (!det || !MAPS[id]) return;
  const m = MAPS[id];
  const lock = mapLockReason(id);
  det.innerHTML = "";
  det.classList.remove("rmap-enter");
  void det.offsetWidth;
  det.classList.add("rmap-enter");

  const h = document.createElement("h3");
  h.textContent = m.name;
  const p = document.createElement("p");
  p.textContent = m.intro;
  det.append(h, p);

  if (moduleLevel(save, "Safe system") >= 1) {
    const nodes = Object.values(m.nodes || {});
    const radar = document.createElement("p");
    radar.className = "radar";
    radar.textContent = `Safe System · lokacji: ${nodes.length} · wrogów: ~${nodes.filter((n) => n.enemy).length} · ewakuacji: ${nodes.filter((n) => n.extract).length}`;
    det.appendChild(radar);
  }

  det.appendChild(
    btn(lock ? `Zablokowane – ${lock}` : "Wyrusz na rajd", () => startRaid(id), lock ? "" : "primary-btn", !!lock)
  );

  document.querySelectorAll("[data-map]").forEach((el) => el.classList.toggle("sel", el.dataset.map === id));
}

// === SEKCJA: AKCJE OGÓLNE ===
function moveBetween(from, to, inst) {
  const name = ITEMS[inst.id].name;
  if (!quickMove(from, to, inst)) return say(`Brak miejsca: ${name}.`, "warn");
  say(`Przeniesiono: ${name}.`);
}

function clearLoadout() {
  const left = [];
  [...save.loadout.items].forEach((o) => {
    if (addToContainer(save.stash, o.id, o.qty)) left.push(o);
  });
  save.loadout.items = left;
  say("Zestaw odłożony do magazynu.");
  persist();
}

function repeatLoadout() {
  clearLoadout();
  let skipped = false;
  save.lastLoadout.forEach((r) => {
    const n = Math.min(r.qty, countItem(save.stash, r.id));
    if (n < r.qty) skipped = true;
    if (!n) return;
    removeById(save.stash, r.id, n);
    const left = addToContainer(save.loadout, r.id, n);
    if (left) {
      skipped = true;
      addToContainer(save.stash, r.id, left);
    }
  });
  say(skipped ? "Część poprzedniego zestawu niedostępna lub nie mieści się w plecaku." : "Poprzedni zestaw załadowany.", skipped ? "warn" : "");
  persist();
}

function rest() {
  if (typeof naturalHealBody === "function") {
    naturalHealBody(save, 300);
  } else {
    const medLvl = moduleLevel(save, "Medstation");
    let target = Math.ceil(save.maxHp * 0.5);
    if (medLvl === 1) target = Math.ceil(save.maxHp * 0.85);
    if (medLvl >= 2) target = save.maxHp;
    save.hp = target;
  }

  grantSkillXp(save, "witalnosc", 10);
  say(`Odpoczywasz w schronie (5 minut). Regeneracja HP i leczenie obrażeń ciała (${save.hp} / ${save.maxHp} HP).`, "hit");
  edgeGlow("heal");
  persist();
}

function startRaid(mapId) {
  window.location.href = `raid.html?map=${mapId}`;
}

// === SEKCJA: SYSTEM MISJI I ZLECEŃ (FILTRY & MAIN QUEST NEON) ===
let questFilterStatus = "active";
let showCompletedQuests = false;

// Nowe zlecenia przyjmują się automatycznie (bez przycisku)
function autoAcceptQuests() {
  save.quests = save.quests || {};
  save.questNew = save.questNew || {};
  let count = 0;
  QUESTS.forEach((q) => {
    if ((save.quests[q.id] || "available") !== "available") return;
    if (getQuestAvailability(q, save) !== "available") return;
    save.quests[q.id] = "active";
    save.questNew[q.id] = true;
    count++;
  });
  if (count > 0) {
    writeSave(save);
    say(count === 1 ? "Nowe zlecenie od handlarza." : `Nowe zlecenia od handlarzy: ${count}.`, "hit");
  }
}

// Ładny checkbox „Pokaż ukończone”
function makeCompletedToggle() {
  const lab = document.createElement("label");
  lab.className = "chk";
  const cb = document.createElement("input");
  cb.type = "checkbox";
  cb.checked = showCompletedQuests;
  cb.onchange = () => {
    showCompletedQuests = cb.checked;
    renderAll();
  };
  const box = document.createElement("span");
  box.className = "chk-box";
  lab.append(cb, box, document.createTextNode(" Pokaż ukończone"));
  return lab;
}

function getQuestAvailability(q, s) {
  s.quests = s.quests || {};

  // Sprawdź czy handlarz jest odblokowany (zależy od poziomu modułu Komunikacji)
  if (typeof availableTraders === "function") {
    const activeTraders = availableTraders();
    const isTraderUnlocked = activeTraders.some((t) => t.id === q.traderId);
    if (!isTraderUnlocked) {
      return "locked_trader";
    }
  }

  const status = s.quests[q.id] || "available";
  if (status === "completed") return "completed";
  if (status === "active") return "active";

  // Misje główne nie mają tierów i są od razu dostępne
  if (q.isMain) return "available";

  // Sprawdź czy handlarz odblokował dany tier
  const traderLvl = typeof getTraderTier === "function" ? getTraderTier(s, q.traderId) : 0;
  if (q.tier !== undefined && q.tier !== null && traderLvl < q.tier) {
    return "locked_tier";
  }

  // Sprawdź progresję faz w obrębie danego tieru handlarza
  const sameTierQuests = QUESTS.filter((x) => x.traderId === q.traderId && x.tier === q.tier && !x.isMain);
  const phase1Quests = sameTierQuests.filter((x) => x.phase === 1);
  const phase2Quests = sameTierQuests.filter((x) => x.phase === 2);
  const baseQuests = [...phase1Quests, ...phase2Quests];

  const phase1DoneCount = phase1Quests.filter((x) => s.quests[x.id] === "completed").length;
  const baseDoneCount = baseQuests.filter((x) => s.quests[x.id] === "completed").length;

  if (q.phase === 1) {
    return "available";
  }
  if (q.phase === 2) {
    if (phase1DoneCount >= 1) return "available";
    return "locked_phase";
  }
  if (q.phase === "final") {
    if (baseDoneCount >= baseQuests.length) return "available";
    return "locked_final";
  }

  return "available";
}

function filterQuestStatus(status) {
  questFilterStatus = status;
  ["ready", "active"].forEach((st) => {
    const b = $(`qfilter-${st}`);
    if (b) {
      if (st === status) b.classList.remove("ghost");
      else b.classList.add("ghost");
    }
  });
  renderQuests();
}

function createQuestCard(q, tr, status) {
  const panel = document.createElement("div");
  panel.className = "panel" + (q.isMain ? " main-quest-card" : "");
  panel.style.borderLeft = `4px solid ${tr.color || "#38bdf8"}`;

  const top = document.createElement("div");
  top.style.display = "flex";
  top.style.justifyContent = "space-between";
  top.style.alignItems = "center";
  top.style.marginBottom = "6px";

  const titleH = document.createElement("h3");
  titleH.style.margin = "0";
  titleH.textContent = q.title;

  const badge = document.createElement("span");
  badge.className = "term-badge";
  badge.style.borderColor = tr.color || "#38bdf8";
  badge.style.color = tr.color || "#38bdf8";

  let tierLabel = q.isMain ? "MISJA GŁÓWNA" : `TIER ${q.tier}`;
  if (q.phase === "final") tierLabel += " // OSTATECZNA";

  const statusLabel = status === "completed" ? "ZAKOŃCZONE" : status === "active" ? "W TRAKCIE" : "DOSTĘPNE";
  badge.textContent = `[${tierLabel}] // ${statusLabel}`;
  top.append(titleH, badge);

  const traderLine = document.createElement("div");
  traderLine.style.fontSize = "0.85rem";
  traderLine.style.color = tr.color || "#94a3b8";
  traderLine.style.fontWeight = "bold";
  traderLine.style.marginBottom = "6px";
  traderLine.textContent = `Zleceniodawca: ${tr.name}`;

  const desc = document.createElement("p");
  desc.style.margin = "4px 0 8px 0";
  desc.textContent = q.desc;

  // Postęp wymaganych zasobów
  const reqBox = document.createElement("div");
  reqBox.style.fontSize = "0.88rem";
  reqBox.style.marginBottom = "8px";
  reqBox.style.padding = "6px 8px";
  reqBox.style.background = "rgba(15, 23, 42, 0.6)";
  reqBox.style.borderRadius = "4px";

  let allReqsMet = true;
  const reqLines = q.req.map((r) => {
    const have = countItem(save.stash, r.id) + countItem(save.loadout, r.id);
    const isMet = have >= r.qty;
    if (!isMet) allReqsMet = false;
    const itemName = ITEMS[r.id]?.name || r.id;
    return `<span style="color:${isMet ? '#4ade80' : '#f87171'}">${isMet ? '[OK]' : '[BRAK]'} ${itemName}: ${have} / ${r.qty}</span>`;
  });
  if (q.kill) {
    const killed = !!(save.kills || {})[q.kill];
    if (!killed) allReqsMet = false;
    reqLines.push('<span style="color:' + (killed ? "#4ade80" : "#f87171") + '">' + (killed ? "[OK]" : "[BRAK]") + " Pokonaj cel zlecenia</span>");
  }
  if (q.task) {
    const termDone = !!(save.taskDone || {})[q.id];
    if (!termDone) allReqsMet = false;
    reqLines.push(
      `<span style="color:${termDone ? '#4ade80' : '#22d3ee'}">${termDone ? '[OK]' : '[BRAK]'} ${q.task.label} w rajdzie (${MAPS[q.task.map]?.nodes?.[q.task.node]?.name || q.task.node})</span>`
    );
  }
  reqBox.innerHTML = `<strong>Wymagane zasoby:</strong> ` + reqLines.join(" | ");

  // Nagroda
  const rewardBox = document.createElement("div");
  rewardBox.style.fontSize = "0.85rem";
  rewardBox.style.color = "#38bdf8";
  rewardBox.style.marginBottom = "10px";
  const repReward = q.reward.rep || 30;
  let rewardText = `Nagroda: +${q.reward.credits} kr, +${q.reward.xp} XP, +${repReward} Reputacji`;
  if (q.reward.item && ITEMS[q.reward.item]) {
    rewardText += `, ${ITEMS[q.reward.item].name}${q.reward.itemQty > 1 ? ` x${q.reward.itemQty}` : ""}`;
  }
  rewardBox.textContent = rewardText;

  // Przyciski akcji
  const actionRow = document.createElement("div");
  actionRow.className = "btn-row";

  if (status === "completed") {
    const doneLabel = document.createElement("span");
    doneLabel.style.color = "#10b981";
    doneLabel.style.fontWeight = "bold";
    doneLabel.textContent = "[ZLECENIE WYKONANE I ODEBRANE]";
    actionRow.appendChild(doneLabel);
  } else if (status === "active") {
    actionRow.appendChild(
      btn(
        allReqsMet ? "Oddaj zlecenie i odbierz nagrodę" : "Zbierz wymagane przedmioty...",
        () => turnInQuest(q.id),
        allReqsMet ? "primary-btn" : "ghost",
        !allReqsMet
      )
    );
  }

  // Nowe zlecenie mruga, dopóki nie najedziemy na nie myszką
  if (save.questNew && save.questNew[q.id]) {
    panel.classList.add("quest-new");
    panel.addEventListener(
      "mouseenter",
      () => {
        panel.classList.remove("quest-new");
        delete save.questNew[q.id];
        writeSave(save);
      },
      { once: true }
    );
  }

  panel.append(top, traderLine, desc, reqBox, rewardBox, actionRow);
  return panel;
}

function renderQuests() {
  const box = $("quests-list");
  if (!box || typeof QUESTS === "undefined") return;
  box.innerHTML = "";
  save.quests = save.quests || {};
  autoAcceptQuests();

  const slot = $("qchk-slot");
  if (slot) {
    slot.innerHTML = "";
    slot.appendChild(makeCompletedToggle());
  }

  const list = QUESTS.filter((q) => {
    const avail = getQuestAvailability(q, save);
    if (avail.startsWith("locked")) return false;

    const status = save.quests[q.id] || "available";
    if (status === "completed") return showCompletedQuests;

    const allReqsMet =
      q.req.every((r) => countItem(save.stash, r.id) + countItem(save.loadout, r.id) >= r.qty) &&
      (!q.task || !!(save.taskDone || {})[q.id]) &&
      (!q.kill || !!(save.kills || {})[q.kill]);

    if (questFilterStatus === "ready") return status === "active" && allReqsMet;
    return status === "active";
  });

  if (!list.length) {
    box.innerHTML = save.tutorialDone && questFilterStatus !== "ready" && !showCompletedQuests
      ? `<p class="hint">Brak aktywnych zleceń. Samouczek zaliczony: nowa mapa <strong>Tytan - Kopuła Nowy Ereb</strong> jest już otwarta. Wybierz ją na ekranie rajdu, a zlecenia handlarzy pojawią się w miarę postępów.</p>`
      : `<p class="hint">Brak zleceń w tym widoku.</p>`;
    return;
  }

  list.forEach((q) => {
    const tr = TRADERS.find((t) => t.id === q.traderId) || { name: "Handlarz", color: "#38bdf8" };
    const status = save.quests[q.id] || "available";
    box.appendChild(createQuestCard(q, tr, status));
  });
}

function turnInQuest(questId) {
  const q = QUESTS.find((x) => x.id === questId);
  if (!q || save.quests[questId] !== "active") return;
  if (q.kill && !(save.kills || {})[q.kill]) return say("Najpierw pokonaj cel zlecenia.", "warn");
  if (q.task && !(save.taskDone || {})[q.id]) {
    return say(`Najpierw wykonaj zadanie w rajdzie (${q.task.label}).`, "warn");
  }

  const canTurnIn = q.req.every((r) => {
    const total = countItem(save.stash, r.id) + countItem(save.loadout, r.id);
    return total >= r.qty;
  });

  if (!canTurnIn) return say("Nie posiadasz wszystkich wymaganych przedmiotów.", "warn");

  q.req.forEach((r) => {
    let needed = r.qty;
    const inLoad = countItem(save.loadout, r.id);
    if (inLoad > 0) {
      const take = Math.min(needed, inLoad);
      removeById(save.loadout, r.id, take);
      needed -= take;
    }
    if (needed > 0) {
      removeById(save.stash, r.id, needed);
    }
  });

  save.credits += q.reward.credits;
  const ups = grantXp(save, q.reward.xp);
  if (q.reward.item && ITEMS[q.reward.item]) {
    addToContainer(save.stash, q.reward.item, q.reward.itemQty || 1);
  }

  save.quests[questId] = "completed";
  save.completedQuests = save.completedQuests || [];
  if (!save.completedQuests.includes(questId)) save.completedQuests.push(questId);

  // Dodawanie reputacji u handlarza
  save.traderRep = save.traderRep || {};
  const prevTier = typeof getTraderTier === "function" ? getTraderTier(save, q.traderId) : 0;
  const repGain = q.reward.rep || 30;
  save.traderRep[q.traderId] = (save.traderRep[q.traderId] || 0) + repGain;
  const newTier = typeof getTraderTier === "function" ? getTraderTier(save, q.traderId) : 0;

  const trObj = TRADERS.find((t) => t.id === q.traderId);
  let repMsg = ` (+${repGain} Reputacji u ${trObj ? trObj.name : "handlarza"})`;
  if (newTier > prevTier) {
    repMsg += ` ➔ [AWANS HANDLARZA NA TIER ${newTier}!] Odblokowano nowe towary w sklepie i nowe zlecenia!`;
    edgeGlow("level");
  }

  say(`Zlecenie "${q.title}" zakończone sukcesem! Nagroda: +${q.reward.credits} kr, +${q.reward.xp} XP${repMsg}${ups ? ` (Awans na poziom ${save.level}!)` : ""}.`, "hit");
  edgeGlow("extract");
  persist();
}

